import logging
# from turtle import home

logging.basicConfig(level=logging.ERROR)
import re
import sys
import os
import json
import math
import copy
import faiss
from datetime import datetime, timedelta, time
from typing import Dict, Any, List, Tuple

import numpy as np
from dotenv import load_dotenv
load_dotenv()

# from langchain.chat_models import ChatOpenAI
# from langchain_community.chat_models import ChatOpenAI
from langchain_openai import ChatOpenAI
# from langchain_community.llms import OpenAI
from langchain_community.docstore import InMemoryDocstore
# from langchain.embeddings import OpenAIEmbeddings
from langchain_openai.embeddings import OpenAIEmbeddings
from langchain.retrievers import TimeWeightedVectorStoreRetriever
# from langchain.vectorstores import FAISS
from langchain_community.vectorstores import FAISS
from langchain.utils import mock_now
from langchain_experimental.generative_agents import GenerativeAgentMemory
from langchain.chains.conversation.memory import ConversationBufferWindowMemory

from agent_simulation.custom_agent import GenerativeAgent
from agent_simulation.prompts import AgentPrompt
from agent_simulation.utils import (extract_agent_action, 
                                    load_agent_info, 
                                    save_plans, 
                                    format_time_with_date,
                                    )

# from home_bot.homebot_agent import HomebotAgent
from home_bot.homebot_init import homebot
from device_simulation.device_factory import CustomDeviceFactory


# print(get_floor_data(os.path.join(os.getcwd(), 'data', 'envData')))

# ======== Set the OpenAI API key ======== #
os.environ['OPENAI_API_KEY'] = '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'
openai_api_key_embedding = os.getenv('OPENAI_API')
openai_api_key = os.getenv('OPENAI_API_KEY')
openai_api_base='https://api.openai.com/v1'
# openai_api_key = os.getenv('OPENAI_API')
# openai_api_base = "https://openrouter.ai/api/v1"
headers={"HTTP-Referer": "https://localhost:3000/"}
if openai_api_key is None:
    print("API_KEY environment variable not found. Please set the API key.")
    sys.exit()
else:
    print("API_KEY set up correctly!")
    print("+"*20)

# ======== Set the OpenAI AI engine ======== #
# LLM = ChatOpenAI(max_tokens=5000, model_name='gpt-4-0314', temperature=0.0)
# BOT_LLM = ChatOpenAI(max_tokens=2000, model_name='gpt-4-0613', temperature=0.0)
LLM = ChatOpenAI(max_tokens=8000, model_name='gpt-4o-2024-08-06', temperature=0.0, openai_api_key=openai_api_key, openai_api_base=openai_api_base)

# LLM = ChatOpenAI(max_tokens=8000, model_name='gpt-4o-mini', temperature=0.0, openai_api_key=openai_api_key, openai_api_base=openai_api_base)
# LLM = ChatOpenAI(max_tokens=8000, model_name='gpt-3.5-turbo-16k', temperature=0.0, openai_api_key=openai_api_key)
# BOT_LLM = ChatOpenAI(max_tokens=2000, model_name='gpt-4-32k-0314', temperature=0.0, openai_api_key=openai_api_key, openai_api_base=openai_api_base, headers=headers)

# ======== Define the relevance score function ======== #
def relevance_score_fn(score: float) -> float:
    """Return a similarity score on a scale [0, 1]."""
    # This will differ depending on a few things:
    # - the distance / similarity metric used by the VectorStore
    # - the scale of your embeddings (OpenAI's are unit norm. Many others are not!)
    # This function converts the euclidean norm of normalized embeddings
    # (0 is most similar, sqrt(2) most dissimilar)
    # to a similarity function (0 to 1)
    return 1.0 - score / math.sqrt(2)

# ======== Define the agent memory ======== #
def create_agent_memory(retriever: bool = False) -> GenerativeAgentMemory:
    """Create a new vector store retriever unique to the agent."""
    # Define your embedding model
    embeddings_model = OpenAIEmbeddings(openai_api_key=openai_api_key_embedding)
    # Initialize the vectorstore as empty
    embedding_size = 1536
    index = faiss.IndexFlatL2(embedding_size)
    vectorstore = FAISS(
        embeddings_model.embed_query,
        index,
        InMemoryDocstore({}),
        {},
        relevance_score_fn=relevance_score_fn,
    )
    memory_retriever = TimeWeightedVectorStoreRetriever(
        vectorstore=vectorstore, other_score_keys=["importance"], k=15
    )
    # Define the agent memory
    agent_memory = GenerativeAgentMemory(
        llm=LLM,
        memory_retriever=memory_retriever,
        verbose=False,
        reflection_threshold=8,  # we will give this a relatively low number to show how reflection works
    )
    if retriever:
        return memory_retriever
    else:
        return agent_memory

# ======== Define the agents ======== # 
def agent_init(agent_info: dict) -> GenerativeAgent:
    """Initialize the agent."""
    agent = GenerativeAgent(
        name=agent_info['name'],
        age=agent_info['age'],
        traits=', '.join(agent_info['preference']),
        status=agent_info['curr_room'],
        memory_retriever=create_agent_memory(retriever=True),
        llm=LLM,
        memory=create_agent_memory(retriever=False),
        verbose=True,
    )
    return agent

def env_init():
    device_factory = CustomDeviceFactory("device_simulation/devices.json")
    all_devices = device_factory.show_devices()
    for device_name, dev_model in all_devices.items():
        room_name, dev_name = device_name.split(":")
        
        current_dir = os.getcwd()
        env_data_path = os.path.join(current_dir, 'data', 'envData', f'{room_name}_data.json')
        # open env data
        with open(env_data_path, 'r', encoding='utf-8') as f:
            env_data = json.load(f)

        current_status = device_factory.check_device_status(device_name)
        if "power" in current_status:
            if current_status["power"] == "off":
                env_data[dev_name] = {"power": "off"}
            else:
                env_data[dev_name] = current_status
        else:
            env_data[dev_name] = current_status

        # save env data
        with open(env_data_path, 'w', encoding='utf-8') as f:
            json.dump(env_data, f, indent=4)
    return device_factory

def init_device_steps(device_steps):
    device_steps["init"] = []
    current_dir = os.getcwd()
    env_data_folder_path = os.path.join(current_dir, 'data', 'envData')
    all_env_data_files = sorted(os.listdir(env_data_folder_path))
    for file_name in all_env_data_files:
        if file_name.endswith(".json"):
            env_data_path = os.path.join(current_dir, 'data', 'envData', file_name)
            with open(env_data_path, 'r', encoding='utf-8') as f:
                env_data = json.load(f)
            device_steps["init"].append(env_data)
    return device_steps
    
def update_device_steps(device_steps: dict, steps: list, agent_type: str, plan: str, act: str):
    for step in steps:
        if step[0].tool == 'Device Control in Multiple Rooms' or step[0].tool == 'Device Control':
            if isinstance(step[1], list) or isinstance(step[1], dict):
                device_steps[plan][agent_type].append(step[1])

    return device_steps

def load_agent_info(filepath):
    with open(filepath, 'r') as f:
        info = json.load(f)
        if not isinstance(info, list):
            raise TypeError(f"Expected a dictionary but got {type(info)} from {filepath}")
        return info

def save_agent_info(info, filepath):
    with open(filepath, 'w') as f:
        json.dump(info, f, indent=4)

def get_day_schedule(agent_info, day):
    for day_info in agent_info:
        if day_info['daily_plan'] == day:
            return day_info
    return None

def get_agent_prompt(agent_name, day_info, life_style):
    if agent_name == "emma":
        morning_prompt = AgentPrompt.EMMA_MORNINGS_PROMPT
        evening_prompt = AgentPrompt.EMMA_EVENINGS_PROMPT.format(life_style)
    elif agent_name == "jason":
        morning_prompt = AgentPrompt.JASON_MORNINGS_PROMPT.format(day_info['name'])
        evening_prompt = AgentPrompt.JASON_EVENINGS_PROMPT.format(day_info['name'], life_style)
    elif agent_name == "tommie":
        morning_prompt = AgentPrompt.TOMMIE_MORNINGS_PROMPT.format(day_info['name'])
        evening_prompt = AgentPrompt.TOMMIE_EVENINGS_PROMPT.format(day_info['name'], life_style)
    elif agent_name == "amber":
        morning_prompt = AgentPrompt.AMBER_MORNINGS_PROMPT.format(day_info['name'])
        evening_prompt = AgentPrompt.AMBER_EVENINGS_PROMPT.format(day_info['name'], life_style)
    return morning_prompt, evening_prompt

def save_updated_plans(plan_list, current_plan, agent_info, agent_info_path):
    plan_list, current_plan, agent_info = save_plans(plan_list, agent_info_path)
    save_agent_info(agent_info, agent_info_path)
    return current_plan

def generate_default_plan(agent_name):
    # 示例默认计划生成逻辑，您可以根据实际需求进行修改
    return [{
        "start_date": "2023-09-01",
        "start_time": "08:00",
        "end_time": "10:00",
        "action": "Default Action",
        "act_place": "Default Place",
        "name": agent_name
    }]

############################################################################################################
#                                                                                                          #
#                                                                                                          #
#   Agent simulation starts below                                                                          #
#                                                                                                          #
#                                                                                                          #
############################################################################################################

def run():
    # ======== Init Env Data ======== #
    device_factory = env_init()
    support_models = list(np.unique([x.split(":")[1] for x in device_factory.show_devices().keys()]))

    # ======== Init Homebot ======== #

    agent_info_dir = os.path.join(os.getcwd(), 'data', 'agentData')

    # 调试函数以查看加载后的内容
    def debug_load_and_initialize(agent_info_dir):
        agent_info = load_agent_info(agent_info_dir)
        #print(f"Loaded agent info from {agent_info_dir}: {agent_info[0]}")  # 打印第一个元素进行调试
        agent = agent_init(agent_info[0])  # 初始化时使用第一个元素
        return agent, agent_info

    # 获取指定日期的计划信息
    def get_day_schedule(agent_info, day: str):
        for day_info in agent_info:
            if day_info['daily_plan'] == day:
                return day_info['act_plan']
        return []

    # 读取Agent.json文件并获取其中的星期几
    def get_agent_day(agent_info_dir: str, agent_name: str) -> Any:
        agent_json_path = os.path.join(agent_info_dir, f'{agent_name}.json')
        with open(agent_json_path, 'r') as f:
            agent_data = json.load(f)

        if isinstance(agent_data, list):
            # 假设 daily_plan 是列表中的每个对象的属性
            daily_plans = [item.get('daily_plan', {}) for item in agent_data]
        else:
            daily_plans = agent_data.get('daily_plan', None)

        if daily_plans is None:
            raise ValueError(f"No 'daily_plan' found in JSON file for {agent_name}.")

        return daily_plans

    days_list = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

    # =============== 初始化所有代理 =============== #
    # 初始化所有代理并生成初始计划
    emma_info_dir = os.path.join(agent_info_dir, 'emma.json')
    emma, emma_info = debug_load_and_initialize(emma_info_dir)

    jason_info_dir = os.path.join(agent_info_dir, 'jason.json')
    jason, jason_info = debug_load_and_initialize(jason_info_dir)

    tommie_info_dir = os.path.join(agent_info_dir, 'tommie.json')
    tommie, tommie_info = debug_load_and_initialize(tommie_info_dir)

    amber_info_dir = os.path.join(agent_info_dir, 'amber.json')
    amber, amber_info = debug_load_and_initialize(amber_info_dir)

    # 代理字典
    agents = {
        "emma": emma,
        "jason": jason,
        "tommie": tommie,
        "amber": amber
    }

    # 生成初始计划
    emma_plan, jason_plan, tommie_plan, amber_plan = None, None, None, None  # 初始化计划变量
    for agent_name, agent in agents.items():
        if agent_name == "emma":
            agent_info = emma_info
            info_dir = emma_info_dir
        elif agent_name == "jason":
            agent_info = jason_info
            info_dir = jason_info_dir
        elif agent_name == "tommie":
            agent_info = tommie_info
            info_dir = tommie_info_dir
        elif agent_name == "amber":
            agent_info = amber_info
            info_dir = amber_info_dir

        current_day_info = get_day_schedule(agent_info, days_list[0])
        if not current_day_info:
            print(f"No schedule found for {days_list[0]}, generating default plan for {agent_name}")
            current_day_info = generate_default_plan(agent_name)

        # 确保 current_day_info 是一个包含字典的列表
        if isinstance(current_day_info, list):
            day_info = current_day_info[0]  # 获取当天的第一个计划
        else:
            day_info = current_day_info

        try:
            life_style = ", ".join(day_info['life_style']) if 'life_style' in day_info else "No lifestyle information"
        except KeyError:
            life_style = "No lifestyle information"
        morning_prompt, evening_prompt = get_agent_prompt(agent_name, day_info, life_style)

        observations = [
            f"{agent_name.capitalize()} is your {'son' if agent_name == 'tommie' else 'wife' if agent_name == 'jason' else 'daughter' if agent_name == 'amber' else 'mum'}.",
            f"{agent_name.capitalize()} is hungry.",
            f"{agent_name.capitalize()} needs to get ready for work." if agent_name not in ["tommie", "amber"] else f"{agent_name.capitalize()} needs to get ready for school." if agent_name == "tommie" else f"{agent_name.capitalize()} needs to get ready for class.",
        ]
        for observation in observations:
            with mock_now(datetime(2023, 9, 1, 6, 0)):
                agent.memory.add_memory(observation)

        morning_plan = agent.make_plan(morning_prompt)
        evening_plan = agent.make_plan(evening_prompt)

        plan_list, current_plan, agent_info = save_plans(morning_plan + evening_plan, info_dir, days_list[0])

        if agent_name == "emma":
            emma_plan = current_plan
            print("====", "emma_plan", "====")
            print(*plan_list, sep="\n")
            print("+" * 15)
        elif agent_name == "jason":
            jason_plan = current_plan
            print("====", "jason_plan", "====")
            print(*plan_list, sep="\n")
            print("+" * 15)
        elif agent_name == "tommie":
            tommie_plan = current_plan
            print("====", "tommie_plan", "====")
            print(*plan_list, sep="\n")
            print("+" * 15)
        elif agent_name == "amber":
            amber_plan = current_plan
            print("====", "amber_plan", "====")
            print(*plan_list, sep="\n")
            print("+" * 15)

        agent_info[0]['act_plan'] = current_plan['plan']
        save_agent_info(agent_info, info_dir)

    print("Initial plans generated.")

    # 生成一周的计划
    for day_offset in range(1, 7):  # 从第 2 天到第 7 天
        current_date = (datetime.strptime("2023-09-01", "%Y-%m-%d") + timedelta(days=day_offset)).strftime("%Y-%m-%d")

        for agent_name, agent in agents.items():
            if agent_name == "emma":
                agent_info = emma_info
                info_dir = emma_info_dir
                previous_plan = emma_plan['plan']
                life_style = ", ".join(agent_info[0]['life_style'])
                morning_prompt_template = AgentPrompt.EMMA_NEXT_DAY_MORNINGS_PROMPT.format(date=current_date,
                                                                                           previous_plan=previous_plan)
                evening_prompt_template = AgentPrompt.EMMA_NEXT_DAY_EVENINGS_PROMPT.format(date=current_date,
                                                                                           previous_plan=previous_plan,
                                                                                           life_style=life_style)
            elif agent_name == "jason":
                agent_info = jason_info
                info_dir = jason_info_dir
                previous_plan = jason_plan['plan']
                life_style = ", ".join(agent_info[0]['life_style'])
                morning_prompt_template = AgentPrompt.JASON_NEXT_DAY_MORNINGS_PROMPT.format(date=current_date,
                                                                                            previous_plan=previous_plan)
                evening_prompt_template = AgentPrompt.JASON_NEXT_DAY_EVENINGS_PROMPT.format(date=current_date,
                                                                                            previous_plan=previous_plan,
                                                                                            life_style=life_style)
            elif agent_name == "tommie":
                agent_info = tommie_info
                info_dir = tommie_info_dir
                previous_plan = tommie_plan['plan']
                life_style = ", ".join(agent_info[0]['life_style'])
                morning_prompt_template = AgentPrompt.TOMMIE_NEXT_DAY_MORNINGS_PROMPT.format(date=current_date,
                                                                                             previous_plan=previous_plan)
                evening_prompt_template = AgentPrompt.TOMMIE_NEXT_DAY_EVENINGS_PROMPT.format(date=current_date,
                                                                                             previous_plan=previous_plan,
                                                                                             life_style=life_style)
            elif agent_name == "amber":
                agent_info = amber_info
                info_dir = amber_info_dir
                previous_plan = amber_plan['plan']
                life_style = ", ".join(agent_info[0]['life_style'])
                morning_prompt_template = AgentPrompt.AMBER_NEXT_DAY_MORNINGS_PROMPT.format(date=current_date,
                                                                                           previous_plan=previous_plan)
                evening_prompt_template = AgentPrompt.AMBER_NEXT_DAY_EVENINGS_PROMPT.format(date=current_date,
                                                                                           previous_plan=previous_plan,
                                                                                           life_style=life_style)

            # 生成早晨和晚上的计划
            morning_plan = agent.make_plan_with_previous(morning_prompt_template, day_offset, is_morning=True)
            evening_plan = agent.make_plan_with_previous(evening_prompt_template, day_offset, is_morning=False)

            plan_list, current_plan, agent_info = save_plans(morning_plan + evening_plan, info_dir, days_list[day_offset])

            if agent_name == "emma":
                emma_plan = current_plan
            elif agent_name == "jason":
                jason_plan = current_plan
            elif agent_name == "tommie":
                tommie_plan = current_plan
            elif agent_name == "amber":
                amber_plan = current_plan

            index = days_list.index(days_list[day_offset])
            agent_info[index]['act_plan'] = current_plan['plan']
            save_agent_info(agent_info, info_dir)

            print(f"==== {agent_name.capitalize()}'s Plan for Day {day_offset + 1} ====")
            print(*plan_list, sep="\n")
            print("+" * 15)

    emma_day = get_agent_day(agent_info_dir, "emma")
    jason_day = get_agent_day(agent_info_dir, "jason")
    tommie_day = get_agent_day(agent_info_dir, "tommie")
    amber_day = get_agent_day(agent_info_dir, "amber")
    # ======== Start all agents plan in a single loop ======== #
    persons = {
        "Emma": [emma, emma_info],
        "Jason": [jason, jason_info],
        "Tommie": [tommie, tommie_info],
        "Amber": [amber, amber_info]
    }

    plans = {
        "Emma": [],
        "Jason": [],
        "Tommie": [],
        "Amber": []
    }

    for name, (days, info) in persons.items():
        for day in days:
            for day_info in info:
                day = day_info['daily_plan']
                acts = day_info['act_plan']
                plans[name].append({day: acts})

    # plans 字典现在包含了所有代理人的计划
    emma_acts = plans["Emma"]
    jason_acts = plans["Jason"]
    tommie_acts = plans["Tommie"]
    amber_acts = plans["Amber"]

    # emma_acts = get_day_schedule(emma_info, emma_day)
    # jason_acts = get_day_schedule(jason_info, jason_day)
    # tommie_acts = get_day_schedule(tommie_info, tommie_day)
    #combined_plans = emma_plan['plan'] + jason_plan['plan'] + tommie_plan['plan']
    combined_plans = emma_acts + jason_acts + tommie_acts + amber_acts

    # Create a deep copy of combined_plans
    copied_combined_plans = copy.deepcopy(combined_plans)

    # Add start_time_obj and end_time_obj to each activity in the copied list
    # for act in copied_combined_plans:
    #     act["start_time_obj"] = datetime.strptime(act["start_time"], "%H:%M").time()
    #     act["end_time_obj"] = datetime.strptime(act["end_time"], "%H:%M").time()

    for day_plan in copied_combined_plans:
        for day, activities in day_plan.items():
            for act in activities:
                if "start_time" in act and "end_time" in act:
                    act["start_time_obj"] = datetime.strptime(act["start_time"], "%H:%M").time()
                    act["end_time_obj"] = datetime.strptime(act["end_time"], "%H:%M").time()

    # Sort the copied list
    #sorted_acts = sorted(copied_combined_plans, key=lambda x: x["start_time_obj"])
    #sorted_acts = sorted(copied_combined_plans, key=lambda x: (x["start_date"], x["start_time_obj"]))
    # def sort_key(act):
    #     start_datetime = datetime.combine(
    #         datetime.strptime(act["start_date"], "%Y-%m-%d"),
    #         act["start_time_obj"]
    #     )
    #     # If the time is before 6 AM, consider it as after'end of the previous day
    #     if act["start_time_obj"] < time(6, 0):
    #         start_datetime += timedelta(days=1)
    #     return start_datetime
    # Sort the copied list
    def sort_key(act: Dict[str, Any]) -> datetime:
        for day in days_list:
            if day in act:
                day_activities = act[day]

                # 如果找到了活动列表，访问每个活动对象中的 'start_date' 和 'start_time_obj'
                for activity in day_activities:
                    start_date = activity.get('start_date')
                    start_time_obj = activity.get('start_time_obj')

                    # 组合日期和时间生成 datetime 对象
                    if start_time_obj:
                        start_datetime = datetime.combine(
                            datetime.strptime(start_date, "%Y-%m-%d"),
                            start_time_obj
                        )
                        # 如果时间早于上午 6 点，将其视为前一天的结束
                        if start_time_obj < datetime.strptime("06:00", "%H:%M").time():
                            start_datetime += timedelta(days=1)
                        return start_datetime

            # 如果没有找到匹配的天数和活动，则返回一个较大的默认 datetime 值，以便排在末尾
        return datetime.max


    # # 去除重复的活动
    # unique_combined_plans = []
    # seen_activities = set()
    #
    # for day_plan in copied_combined_plans:
    #     for activities in day_plan.items():
    #         for act in activities:
    #             if isinstance(act, dict):
    #                 # 使用活动的 'start_date'、'start_time_obj' 和 'action' 作为唯一标识符
    #                 start_date = act.get("start_date")
    #                 start_time_obj = act.get("start_time_obj")
    #                 action = act.get("action")
    #
    #                 # 确保 'start_date'、'start_time_obj' 和 'action' 都存在
    #                 if start_date and start_time_obj and action:
    #                     act_repr = (start_date, start_time_obj, action)
    #                     if act_repr not in seen_activities:
    #                         seen_activities.add(act_repr)
    #                         unique_combined_plans.append(act)

    # Sort the acts
    sorted_acts = sorted(copied_combined_plans, key=sort_key)

    unique_sorted_acts = []
    for item in sorted_acts:
        if item not in unique_sorted_acts:
            unique_sorted_acts.append(item)
    sorted_acts = unique_sorted_acts

    def merge_and_sort_activities_by_time(acts: List[Dict[str, List[Dict[str, Any]]]]) -> List[
        Dict[str, List[Dict[str, Any]]]]:
        # 合并活动信息，并转换为包含 datetime 对象的元组
        all_activities: List[Tuple[datetime, str, Dict[str, Any]]] = []
        for day_info in acts:
            for day, day_activities in day_info.items():
                for activity in day_activities:
                    # 使用 datetime 对象便于排序
                    datetime_obj = datetime.strptime(activity['start_date'] + ' ' + activity['start_time'],
                                                     '%Y-%m-%d %H:%M')
                    all_activities.append((datetime_obj, day, activity))

        # 按 datetime 对象排序活动
        all_activities.sort(key=lambda x: x[0])

        # 重组排序后的活动列表
        sorted_activities_dict: Dict[str, List[Dict[str, Any]]] = {}
        for datetime_obj, day, activity in all_activities:
            if day not in sorted_activities_dict:
                sorted_activities_dict[day] = []
            sorted_activities_dict[day].append(activity)

        # 转换成所需的列表格式
        sorted_activities_list = [{day: activities} for day, activities in sorted_activities_dict.items()]

        return sorted_activities_list

    sorted_acts = merge_and_sort_activities_by_time(sorted_acts)



    # Loop through sorted acts and print the output
    agent_steps = {}
    homebot_steps = {}
    device_steps = {}
    index = 0
    # all_preference = f"Emma: {' '.join(emma_info['preference'])}\nTommie: {' '.join(tommie_info['preference'])}\nJason: {' '.join(jason_info['preference'])}"
    all_preference = f"Emma: {' '.join(emma_info[0]['preference'])}\nTommie: {' '.join(tommie_info[0]['preference'])}\nJason: {' '.join(jason_info[0]['preference'])}\nAmber: {' '.join(amber_info[0]['preference'])}"

    print(all_preference)

    agent_steps_path = os.path.join(os.getcwd(), 'data', 'simulationData', 'agent_steps.json')
    homebot_steps_path = os.path.join(os.getcwd(), 'data', 'simulationData', 'homebot_steps.json')
    device_steps_path = os.path.join(os.getcwd(), 'data', 'simulationData', 'device_steps.json')

    device_steps = init_device_steps(device_steps)

    for day_plan in sorted_acts:
            for day, activities in day_plan.items():
                day_activities = activities
                for act in day_activities:
                    #TODO: update the code for 3 persons
                    person_name = act['name']
                    idle_person_names = [name for name in persons if name != person_name]

                    print("-"*15)
                    plan = f"{person_name}: [{act['start_date']} - {act['start_time']} - {act['end_time']}] {act['action']}- {act['act_place']}"
                    # print(plan)

                    tmp_start_hour, tmp_start_min = act['start_time'].split(":")
                    tmp_start_hour = int(tmp_start_hour)
                    tmp_start_min = int(tmp_start_min)

                    with mock_now(datetime(2023, 9, 1, tmp_start_hour, tmp_start_min)):
                        if person_name == "Emma":
                            emma.memory.add_memory(plan)
                        elif person_name == "Jason":
                            jason.memory.add_memory(plan)
                        elif person_name == "Tommie":
                            tommie.memory.add_memory(plan)
                        elif person_name == "Amber":
                            amber.memory.add_memory(plan)

                    person_object = persons.get(person_name)[0]
                    person_info = persons.get(person_name)[1][days_list.index(day)]
                    # print(person_info)
                    idle_person_info_1 = persons.get(idle_person_names[0])[1][days_list.index(day)]
                    idle_person_info_2 = persons.get(idle_person_names[1])[1][days_list.index(day)]
                    idle_person_info_3 = persons.get(idle_person_names[2])[1][days_list.index(day)]

                    if person_object:
                        if day == person_info['daily_plan']:
                            # # Write current room to the agent info
                            # person_info['curr_room'] = act['act_place']
                            # #
                            # # Write current time to the agent info
                            # if person_info['curr_time']:
                            #     curr_date_time = person_info['curr_time']
                            #     new_date_time = format_time_with_date(plan, curr_date_time)
                            #     print("====", new_date_time, "====")
                            #     person_info['curr_time'] = new_date_time
                            # #
                            # # Write current task to the agent info
                            # person_info['curr_task'] = act['action']
                            #
                            # with open(os.path.join(agent_info_dir, f"{person_name.lower()}.json"), 'w') as f:
                            #     json.dump(person_info, f, indent=4)
                            filepath = os.path.join(agent_info_dir, f"{person_name.lower()}.json")

                            # 读取当前的 agent 信息
                            with open(filepath, 'r') as f:
                                data = json.load(f)

                            # 查找并提取目标 `daily_plan` 对应的对象
                            file_info = next((item for item in data if item['daily_plan'] == day), {})

                            # 确保 file_info 是一个字典
                            if not isinstance(file_info, dict):
                                file_info = {}

                            # Write current room to the agent info
                            file_info['curr_room'] = act['act_place']

                            # Write current time to the agent info
                            if 'curr_time' in file_info:
                                curr_date_time = file_info['curr_time']
                                new_date_time = format_time_with_date(plan, curr_date_time)
                                print("====", new_date_time, "====")
                                file_info['curr_time'] = new_date_time

                            # Write current task to the agent info
                            file_info['curr_task'] = act['action']

                            # 将修改后的数据重新写回 data 中
                            for i, item in enumerate(data):
                                if item['daily_plan'] == day:
                                    data[i] = file_info
                                    break

                            # 将更新后的信息写回文件中
                            with open(filepath, 'w') as f:
                                json.dump(data, f, indent=4)
                        #for agent_day in [emma_day, jason_day, tommie_day]:
                        # filepath = os.path.join(agent_info_dir, f"{person_name.lower()}.json")
                        #
                        # # 读取当前的 agent 信息
                        # with open(filepath, 'r') as f:
                        #     file_info_list = json.load(f)
                        #
                        # # 确保文件信息是列表
                        # if not isinstance(file_info_list, list):
                        #     raise ValueError("The JSON file is not formatted correctly and should be a list containing dictionaries.")
                        #
                        # #match_found = False
                        # for file_info in file_info_list:
                        #     #if file_info['daily_plan'] == agent_day:
                        #         match_found = True
                        #
                        #         # 更新agent信息
                        #         file_info['curr_room'] = act['act_place']
                        #
                        #         curr_date_time = file_info['curr_time']
                        #         new_date_time = format_time_with_date(plan, curr_date_time)
                        #         print("====", new_date_time, "====")
                        #         file_info['curr_time'] = new_date_time
                        #
                        #         file_info['curr_task'] = act['action']
                        #
                        #         # 保持其它字段不变，仅更新上述的三个字段
                        #         file_info.update(
                        #             {key: person_info[key] for key in person_info if
                        #              key in ['curr_room', 'curr_time', 'curr_task']})
                        #         break
                        #
                        # # if not match_found:
                        # #     raise ValueError(f"No matching daily_plan found: {agent_day}")
                        #
                        # # 将更新后的信息写回文件中
                        # with open(filepath, 'w') as f:
                        #     json.dump(file_info_list, f, indent=4)

                        all_status = (f"{person_name} is in: {act['act_place']}, the current status is: {act['action']}",
                                    f"{idle_person_names[0]} is in: {idle_person_info_1['curr_room']}, the current status is: {idle_person_info_1['curr_task']}",
                                    f"{idle_person_names[1]} is in: {idle_person_info_2['curr_room']}, the current status is: {idle_person_info_2['curr_task']}",
                                    f"{idle_person_names[2]} is in: {idle_person_info_3['curr_room']}, the current status is: {idle_person_info_3['curr_task']}")

                        print(all_status)

                        device_steps[plan] = {
                            "start_date": act["start_date"],
                            "start_time": act["start_time"],
                            "end_time": act["end_time"],
                            "bot": [],
                            person_name: []
                        }
                        # TODO: let the homebot change the environment and provide the feedback first
                        bot_response, bot_steps = homebot.change_env(all_preference=all_preference,
                                                                    curr_time=person_info['curr_time'],
                                                                    family_status=all_status,
                                                                    smart_devices=support_models)

                        device_steps = update_device_steps(device_steps, bot_steps, 'bot', plan, act)

                        # let the agent change the environment and provide the feedback
                        response, steps = person_object.change_env(preference=" ".join(person_info['preference']),
                                                                curr_person=person_name,
                                                                curr_room=act['act_place'],
                                                                curr_time=person_info['curr_time'],
                                                                curr_task=act['action'],
                                                                smart_devices=support_models)

                        device_steps = update_device_steps(device_steps, steps, person_name, plan, act)

                        steps = extract_agent_action(steps)
                        bot_steps = extract_agent_action(bot_steps)

                        agent_steps[plan] = [response, steps]
                        homebot_steps[plan] = [bot_response, bot_steps]

                # if index == 5:
                #     break
                    index += 1

    # print(homebot_steps)

    with open(agent_steps_path, 'w') as f:
        json.dump(agent_steps, f, indent=4)

    with open(homebot_steps_path, 'w') as f:
        json.dump(homebot_steps, f, indent=4)

    with open(device_steps_path, 'w') as f:
        json.dump(device_steps, f, indent=4)

    print("Agent_steps is saved into agent_steps.json")
    print("Homebot_steps is saved into homebot_steps.json")
    print("Device_steps is saved into device_steps.json")

    # for task in plan_list:
    #     pass
        # TODO: get the curent taak and room

        # TODO: let the homebot change the environment and provide the feedback first
        
        # TODO: let the agent change the environment and provide the feedback


    # def save_plans(plan_string:str, agent_info_path:str):
    #     # Test the function
    #     plan_list = plan_to_list(plan_string)
    #     curr_plan = []

    #     for item in plan_list:
    #         # print(plan_to_act(item))

    #         agent_info = load_agent_info('agentData/tommie.json')

    #         if agent_info['act_plan'] != []:
    #             curr_plan = agent_info['act_plan']

    #         curr_plan.append(plan_to_act(item))

    #         agent_info['act_plan'] = curr_plan

    #         with open('agentData/tommie.json', 'w') as f:
    #             json.dump(agent_info, f, indent=4)

        # print(agent_info['act_plan'])
        # print("+"*10)

        # tommie_info['act_plan']=tommie_info['act_plan'].append(plan_to_act(item))
        # print(tommie_info['act_plan'])

    # with mock_now(datetime(2023, 9, 1, 7, minutes)):
    #     tommie.memory.add_memory(tommie.make_plan("""It's 7am in the morning, you are Tommie
    #                         You are a computer science student just waking up in your room. 
    #                         You need to plan your morning routine and leave your home before 8:30am.
    #                         """))

    #     tommie.memory.add_memory("Tommie will adjust his morning plan if it conflicts with family members.")

    # print(tommie.get_full_header(force_refresh=True, now=datetime(2023, 9, 1, 7, minutes)))
    # print("="*10)

    # print(tommie.memory)

    # ======== Init Emma ======== #
    # emma_info = load_agent_info('agentData/emma.json')
    # emma = agent_init(emma_info)

    # # We can add memories directly to the memory object
    # # TODO: Update the memory with the observations
    # emma_observations = [
    #     "The road is noisy at night.",
    #     "Tommie is your son.",
    #     "Emma is hungry.",
    #     "Emma needs to get ready for work.",
    # ]

    # minutes = 0
    # for observation in emma_observations:

    #     with mock_now(datetime(2023, 9, 1, 6, minutes)):
    #         emma.memory.add_memory(observation)

    # print(emma.change_env(preference=" ".join(emma_info['preference']), curr_room=emma_info['curr_room']))
    # print("="*10)


    # with mock_now(datetime(2023, 9, 1, 6, minutes)):
    #     emma.memory.add_memory(emma.make_plan("""It's 6am in the morning, you are Emma
    #                         You are a doctor just waking up in your room. 
    #                         You need to plan your morning routine and leave your home before 7:30am.
    #                         """))

    #     emma.memory.add_memory("Emma will adjust his morning plan if it conflicts with family members.")

    # print(emma.get_full_header(force_refresh=True, now=datetime(2023, 9, 1, 6, minutes)))
    # print("="*10)

    # emma_memory = GenerativeAgentMemory(
    #     llm=LLM,
    #     memory_retriever=create_new_memory_retriever(),
    #     verbose=False,
    #     reflection_threshold=8,  # we will give this a relatively low number to show how reflection works
    # )

    # emma_preference = [
    #     "suitable temperture 27C",
    #     "suitable humidity 50%",
    #     "prefer quiet space",
    #     "sleep at 10:00am",
    #     "wake up at 6:00am",
    # ]

    # emma = GenerativeAgent(
    #     name="Emma",
    #     age=49,
    #     traits=','.join(emma_preference),  # You can add more persistent traits here
    #     status="bedroom2",  # When connected to a virtual world, we can have the characters update their status
    #     memory_retriever=create_new_memory_retriever(),
    #     llm=LLM,
    #     memory=emma_memory,
    #     verbose=True,
    # )

    # # tommie_observations = [
    # #     "Tommie finished this week's lectures from the university",
    # #     "Tommie drove back to home",
    # #     "Tommie is now in the new bedroom",
    # #     "Tommie needs to study in his study room",
    # #     ]

    # # We can add memories directly to the memory object
    # # TODO: Update the memory with the observations
    # emma_observations = [
    #     "The road is noisy at night",
    #     "Tommie is your son.",
    #     "Emma is hungry",
    #     "Emma needs to get ready for her job in hospital.",
    # ]

    # minutes = 0

    # for observation in emma_observations:

    #     with mock_now(datetime(2023, 9, 1, 6, minutes)):
    #         emma.memory.add_memory(observation)

    # print(emma.change_env(" ".join(emma_preference)))
    # print("="*10)
    # FIXME
    # with mock_now(datetime(2023, 9, 1, 6, minutes)):
    #     emma.memory.add_memory(emma.make_plan("""It's 6am in the morning, you are Emma.
    #                         You are a doctor just waking up in your room. 
    #                         You need to plan your morning routine and leave your home before 8:30am. 
    #                         """))

    # emma.memory.add_memory("Emma will adjust her morning plan if it conflicts with her family members.")


    # print(tommie.memory)
    # print(tommie.get_summary(force_refresh=True))
    # print("="*10)
    # print(tommie.summarize_related_env(tommie_env_observation))
    # print("="*10)


    # print(emma.get_full_header(force_refresh=True, now=datetime(2023, 9, 1, 6, minutes)))
    # print("="*10)
    # while True:
    #     generate_reaction = tommie.generate_reaction(tommie_observations)

    #     print(generate_reaction)

    #     generate_reaction = tommie.generate_reaction(tommie_env_observation)

    #     print(generate_reaction)

    #     break

    # print("="*10)
    # print(tommie.summarize_env())

    # def run_conversation(agents: List[GenerativeAgent], initial_observation: str) -> None:
    #     """Runs a conversation between agents."""
    #     minutes = 0
    #     _, observation = agents[1].generate_reaction(initial_observation, now=datetime(2023, 9, 1, 7, minutes))
    #     print(observation)
    #     turns = 0
        
    #     while True:
    #         minutes += 3
    #         break_dialogue = False
    #         for agent in agents:
                
    #             stay_in_dialogue, observation = agent.generate_dialogue_response(
    #                 observation, now=datetime(2023, 9, 1, 7, minutes)
    #             )
    #             print(observation)
    #             # If agent says goodbye at the end, break the dialogue
    #             if observation.lower()[:-2].endswith('goodbye'):
    #                 break_dialogue = True
    #             # observation = f"{agent.name} said {reaction}"
    #             if not stay_in_dialogue:
    #                 break_dialogue = True
    #         if break_dialogue:
    #             break
    #         turns += 1

    # agents = [tommie, emma]
    # run_conversation(
    #     agents,
    #     "Tommie said: Morning, Emma. How's your sleep last night?",
    # )

if __name__ == "__main__":
    run()