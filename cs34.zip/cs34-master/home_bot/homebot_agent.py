import re
from typing import Optional
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.schema.language_model import BaseLanguageModel
from langchain.chains.conversation.memory import ConversationBufferWindowMemory
from langchain.agents import initialize_agent
from langchain_experimental.pydantic_v1 import BaseModel

from agent_simulation.prompts import AgentPrompt
from agent_simulation.tools import controlDevice, getEnvData, getFloorData, controlDeviceMulti, getDeviceController
from device_simulation.device_factory import CustomDeviceFactory

device_factory = CustomDeviceFactory("device_simulation/devices.json")
SUPPORT_MODELS = list(np.unique([x.split(":")[1] for x in device_factory.show_devices().keys()]))

class HomebotAgent(BaseModel):
    """A representation of a homebot agent, which is a single LLM autonomous agent."""

    memory: ConversationBufferWindowMemory  # The memory model of the agent
    llm: BaseLanguageModel  # The underlying language model the agent uses.
    verbose: bool = False  # Flag to indicate verbosity.

    global tools
    tools = [controlDevice, getEnvData, getFloorData, controlDeviceMulti, getDeviceController]

    class Config:
        """Configuration settings for the Pydantic object."""
        arbitrary_types_allowed = True

    # @staticmethod
    # def _parse_list(text: str) -> List[str]:
    #     """Converts a text with newline-separated lines into a list of strings."""
    #     lines = re.split(r"\n", text.strip())
    #     return [re.sub(r"^\s*\d+\.\s*", "", line).strip() for line in lines]

    def tool_chain(self) -> LLMChain:
        """Utilizes the LLMChain to generate a response given a prompt."""
        # return LLMChain(llm=self.llm, prompt=prompt, verbose=self.verbose, memory=self.memory)
        # return initialize_agent(tools, self.llm, memory=self.memory, verbose=self.verbose, 
        #                         return_intermediate_steps=True, handle_parsing_errors=True).run(prompt)
        return initialize_agent(tools, self.llm, memory=self.memory, verbose=self.verbose, 
                                return_intermediate_steps=True, handle_parsing_errors=True)
    
    # ==== The following code checks the environment status summaries for the agent. ==== #
    def _get_env_status(self) -> str:
        """Extracts the main entity from an observation text."""

        prompt, output_parser, format_instructions = AgentPrompt.get_env_objects()

        final_prompt = PromptTemplate(input_variables=["getEnvData"],
                                      partial_variables={"format_instructions": format_instructions},
                                      template=prompt).format(getEnvData=getEnvData)
        
        # response = self.tool_chain(final_prompt)

        return output_parser.parse(self.tool_chain(final_prompt))
        # return output_parser.parse(response), response["intermediate_steps"]

    def change_env(self, all_preference:list, curr_time:str, family_status:str, smart_devices:list) -> str:
        """Identifies the action of a specific entity from an observation."""

        prompt, output_parser, format_instructions = AgentPrompt.homebot_change_env()

        final_prompt = PromptTemplate(input_variables=["all_preference", "time", "family_status", "smart_devices", "getFloorData", "controlDeviceMulti", "getDeviceController"],
                                      partial_variables={"format_instructions": format_instructions},
                                      template=prompt).format(all_preference=all_preference,
                                                              time=curr_time,
                                                              family_status=family_status,
                                                              smart_devices=smart_devices,
                                                              getFloorData=getFloorData, 
                                                              controlDeviceMulti=controlDeviceMulti,
                                                              getDeviceController=getDeviceController)
        agent = self.tool_chain()
        response = agent(final_prompt)

        try:
            return output_parser.parse(response["output"]), response["intermediate_steps"]
        except:
            return response["output"], response["intermediate_steps"]
    
    def human_asked_change_env(self, human_name:str, human_requirements:str):

        prompt, output_parser, format_instructions = AgentPrompt.human_asked_homebot_change_env()

        final_prompt = PromptTemplate(input_variables=["human_name", "human_requirements", "getFloorData", "controlDeviceMulti", "getDeviceController"],
                                      partial_variables={"format_instructions": format_instructions},
                                      template=prompt).format(human_name=human_name,
                                                              human_requirements=human_requirements,
                                                              getFloorData=getFloorData, 
                                                              controlDeviceMulti=controlDeviceMulti,
                                                              getDeviceController=getDeviceController)
        
        agent = self.tool_chain()
        response = agent(final_prompt)
        return output_parser.parse(response["output"])
        