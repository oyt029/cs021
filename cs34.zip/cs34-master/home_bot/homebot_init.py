import os
from dotenv import load_dotenv
load_dotenv()

# from langchain.chat_models import ChatOpenAI
from langchain_openai import ChatOpenAI
# from langchain_community.chat_models import ChatOpenAI
from langchain.chains.conversation.memory import ConversationBufferWindowMemory

from home_bot.homebot_agent import HomebotAgent

os.environ['OPENAI_API_KEY'] = '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'
# openai_api_key_embedding = os.getenv('OPENAI_API')
openai_api_key = os.getenv('OPENAI_API_KEY')
# openai_api_key = os.getenv('OPENAI_API')
# openai_api_base = "https://openrouter.ai/api/v1"
# headers={"HTTP-Referer": "https://localhost:3000/"}
# BOT_LLM = ChatOpenAI(max_tokens=2000, model_name='gpt-4-0613', temperature=0.0)
BOT_LLM = ChatOpenAI(max_tokens=2000, model_name='gpt-4o-2024-08-06', temperature=0.0, openai_api_key=openai_api_key)
# BOT_LLM = ChatOpenAI(max_tokens=2000, model_name='gpt-3.5-turbo-16k', temperature=0.0, openai_api_key=openai_api_key)

homebot = HomebotAgent(
    memory=ConversationBufferWindowMemory(memory_key='chat_history', 
                                        k=2, input_key='input', 
                                        output_key="output",
                                        return_messages=True), 
    llm=BOT_LLM, 
    verbose=True)
