import os
import ast
import json

from langchain.agents import Tool

from home_bot.homebot_init import homebot

def get_env_data(room: str):
    current_dir = os.getcwd()

    if room:
        env_data_path = os.path.join(current_dir, 'data', 'envData', f'{room}_data.json')

        with open(env_data_path, 'r') as f:
            env_data = json.load(f)
        
        return env_data
    else:
        return "Please choose the room to get the enviroment data."

def control_home_bot(agent_query: str):

    if 'dict(' in agent_query:
        agent_query = agent_query.replace('dict(', '{').replace(')', '}')

    try:
        agent_query = ast.literal_eval(agent_query)
    except:
        if 'dict' in agent_query:
            return "FORMAT ERROR: You need to use '{' and '}' to instead of dict()."
        else:
            return "FORMAT ERROR: Please try again."
    if "input" not in agent_query or "room" not in agent_query or "name" not in agent_query:
        return 'Miss keys. Please using format: dict("input": "your requirements", "room": "room name", "name": "your name"})'
    requests = agent_query['input']
    human_name = agent_query['name']
    room_name = agent_query['room']
    response = homebot.human_asked_change_env(human_name, requests)
    if response['status'] == 'succeed':
        env_data = get_env_data(room_name)
        return env_data
    
    elif response['status'] == 'fail':
        return response['reason']
    
    else:
        return "Something wrong, please try again."

controlHomeBot = Tool(
    name='Call the Home Bot',
    description=('A tool that let you control the Home Bot by natural language.'
                 'The Home bot is a smart speaker that can control smart devices in the home. You can use natural language to tell homebot to change the environment.'
                 'The first input format is dict("input": "your requirements", "room": "room name", "name": "your name"), the second input is home_bot'),
    func=control_home_bot,)