from device_simulation.util import load_json_file
from device_simulation.modified_miio.devicefactory import DeviceFactory


class CustomDeviceFactory:
    def __init__(self, device_path: str) -> None:
        self.device_path = device_path
        self.devices = self._load_devices()
    
    def _load_devices(self) -> dict:
        data = load_json_file(self.device_path)
        devices = {
            device_info['device_name']: {
                "model_name": device_info['model_name'],
                "location": device_info['device_name'].split(':')[0],
                "device": DeviceFactory.create(
                    host=device_info['ip'], 
                    port=device_info['port'], 
                    token=device_info['token'], 
                    model=device_info['model_name']
                )
            }
            for device_info in data
        }
        return devices

    
    
    def create(self, device_name: str, ip: str, port: int, token: str, model: str) -> None:
        if device_name in self.devices:
            raise NameError("device already exists, please change device_name")
        self.devices[device_name] = {
            "model_name": model,
            "device_type": device_name.split('.')[0],
            "location": device_name.split('.')[1],
            "device": DeviceFactory.create(
                host=ip,
                port=port,
                token=token,
                model=model
            )
        }
    def show_devices(self) -> dict:
        return self.devices
    
    def check_device_status(self, device_name: str) -> dict:
        return self.devices[device_name]['device'].show_status()
    
    def check_device_actions(self, device_name: str) -> dict:
        return self.devices[device_name]['device'].show_actions()
    
    def execute(self, device_name: str, action: str, value: str):
        self.devices[device_name]['device'].execute(action, value)
        return self.devices[device_name]['device'].show_status()