import random
import asyncio

# from device_simulation.modified_miio.miotsimulator import MiotSimulator
# from device_simulation.modified_miio.common import did_and_mac_for_model, create_info_response
# from device_simulation.modified_miio.server import PushServer
from modified_miio.miotsimulator import MiotSimulator
from modified_miio.common import did_and_mac_for_model, create_info_response
from modified_miio.server import PushServer


class ServerManager:
    def __init__(self) -> None:
        self.loop = None
        self.servers = list()
        
    async def init_server(self, model_info: list):
        model, dev, ip, port = model_info
        device_id, mac = did_and_mac_for_model(model)
        server = PushServer(device_id=device_id, device_ip=ip, server_port=port)
        simulator = MiotSimulator(device_model=dev)
        server.add_method("miIO.info", create_info_response(model, ip, mac))
        server.add_method("action", simulator.action)
        server.add_method("get_properties", simulator.get_properties)
        server.add_method("set_properties", simulator.set_properties)
        server.add_method("dump_properties", simulator.dump_properties)
        server.add_method("dump_services", simulator.dump_services)
        server.add_method("dump_actions", simulator.dump_actions)

        self.servers.append(server)
        transport, proto = await server.start()
        
    def start(self, registered_devices: dict):
        self.loop = asyncio.get_event_loop()
        random.seed(1)
        
        for model_name, model_info in registered_devices.items():
            self.loop.run_until_complete(self.init_server(model_info))
        self.loop.run_forever()