# from device_simulation.modified_miio.miotsimulator import SimulatedDeviceModel
from modified_miio.miotsimulator import SimulatedDeviceModel

DEVICE_MODEL_FUNC = {
    'miio': None,
    'miot': SimulatedDeviceModel.parse_file
}

class DeviceManager:
    def __init__(self) -> None:
        self.registered_devices = dict()
        self.port_pool = set()
    
    def register_device(self, device_name, device_info_path: str, device_type: str, ip: str, port: int):
        if port in self.port_pool:
            raise KeyError(f"PORT {port} aleady in use!")
        if device_name in self.registered_devices:
            raise KeyError(f"Device '{device_name}' aleady exists!")
        
        dev = DEVICE_MODEL_FUNC[device_type](device_info_path, encoding='utf-8')
        self.port_pool.add(port)
        self.registered_devices[device_name] = [device_name, dev, ip, port]
    
    def show_registered_devices(self):
        res = {k: {'ip': v[2], 'port': v[3]} for k,v in self.registered_devices.items()}
        return res
    
    def get_registered_devices(self):
        return self.registered_devices
        