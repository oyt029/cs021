import os
import json
from tqdm import tqdm

from miottemplate import download

def main():
    brand = "lumi"
    with_debug_version = True
    with open('device_simulation/download_miot_template/model_miotspec_mapping.json', 'r') as f:
        data = json.load(f)
        
    model_names = {'released': [], 'debug': []}
    model_types = {'released': set(), 'debug': set()}

    for x in data['instances']:
        if x['status'] == 'released' and x['model'].startswith(brand):
            model_names['released'].append(x['model'])
            model_name = x['model'].split('.')
            model_type = model_name[1]
            model_types['released'].add(model_type)
            
        elif x['status'] == 'debug' and x['model'].startswith(brand):
            model_names['debug'].append(x['model'])
            model_name = x['model'].split('.')
            model_type = model_name[1]
            model_types['debug'].add(model_type)

    print("num of released model types: ", len(model_types['released']))
    print("num of debug model types: ", len(model_types['debug']))

    # create save folder
    brand_folder = f'/home/simshome/src/device_simulation/miot_template/{brand}'
    if not os.path.exists(brand_folder):
        os.mkdir(brand_folder)

    released_folder = os.path.join(brand_folder, 'released')
    debugged_folder = os.path.join(brand_folder, 'debug')

    if not os.path.exists(released_folder):
        os.mkdir(released_folder)

    if not os.path.exists(debugged_folder):
        os.mkdir(debugged_folder)


    for version_type, m_types in model_types.items():
        for model_type in m_types:
            type_folder = os.path.join(brand_folder, version_type, model_type)
            if not os.path.exists(type_folder):
                os.mkdir(type_folder)


    for version_type, m_names in model_names.items():
        if not with_debug_version and version_type == 'debug':
            break
        for model_name in tqdm(m_names, total=len(m_names)):
            model_type = model_name.split('.')[1]
            if model_type == "curtain":
                save_path = os.path.join(brand_folder, version_type, model_type)
                download(model=model_name, save_path=save_path, status_filter=version_type)
            # save_path = os.path.join(brand_folder, version_type, model_type)
            # download(model=model_name, save_path=save_path, status_filter=version_type)

if __name__ == '__main__':
    main()