import logging
import enum
from typing import Any, Dict, Union

import click

from miio.click_common import EnumType, command, format_output
from miio.device import DeviceStatus

from device_simulation.modified_miio.miot_device import MiotDevice

_LOGGER = logging.getLogger(__name__)


SUPPORTED_MODELS = ["yeelink.light.lamp1", "yeelink.light.ceiling1"]

_MAPPING_LAMP1 = {
    # Light siid 2
    "power": {"siid": 2, "piid": 1},
    "brightness": {"siid": 2, "piid": 2},
    "color_temperature": {"siid": 2, "piid": 3},
    "mode": {"siid": 2, "piid": 4}
}

_MAPPING_CEILING1 = {
    # Light siid 2
    "power": {"siid": 2, "piid": 1},
    "brightness": {"siid": 2, "piid": 2},
    "mode": {"siid": 2, "piid": 3},
    "color_temperature": {"siid": 2, "piid": 4}
}

_MAPPINGS = {
    "yeelink.light.lamp1": _MAPPING_LAMP1,
    "yeelink.light.ceiling1": _MAPPING_CEILING1
}

class OperationLampMode(enum.Enum):
    Reading = 0
    Computer = 1
    Night_Reading = 2
    Anti_blue = 3
    Effective_Work = 4
    Candle = 5
    Twinkle = 6

class OperationCeilingMode(enum.Enum):
    Day = 1
    Night = 2


class YeelightLampMiotStatus(DeviceStatus):
    """Container for status reports from the air conditioner (MIoT)."""

    def __init__(self, data: Dict[str, Any]) -> None:
        """
        Response (MIoT format) of a Yeelight (yeelink.light.lamp1)
        [
            {'did': 'power', 'siid': 2, 'piid': 1, 'code': 0, 'value': False},
            {'did': 'brightness', 'siid': 2, 'piid': 2, 'code': 0, 'value': 50},
            {'did': 'color_temperature', 'siid': 2, 'piid': 3, 'code': 0, 'value': 6500},
            {'did': 'mode', 'siid': 2, 'piid': 4, 'code': 0, 'value': 0},
        ]
        """
        self.data = data

    @property
    def is_on(self) -> bool:
        """True if the device is turned on."""
        return self.data["power"]

    @property
    def power(self) -> str:
        """Current power state."""
        return "on" if self.is_on else "off"

    @property
    def brightness(self) -> int:
        """brightness"""
        return self.data["brightness"]

    @property
    def color_temperature(self) -> int:
        """Color temperature."""
        return self.data["color_temperature"]

    @property
    def mode(self) -> OperationLampMode:
        """Current operation mode."""
        return OperationLampMode(self.data['mode'])

class YeelightCeilingMiotStatus(DeviceStatus):
    """Container for status reports from the air conditioner (MIoT)."""

    def __init__(self, data: Dict[str, Any]) -> None:
        """
        Response (MIoT format) of a Yeelight (yeelink.light.lamp1)
        [
            {'did': 'power', 'siid': 2, 'piid': 1, 'code': 0, 'value': False},
            {'did': 'brightness', 'siid': 2, 'piid': 2, 'code': 0, 'value': 50},
            {'did': 'color_temperature', 'siid': 2, 'piid': 3, 'code': 0, 'value': 6500},
            {'did': 'mode', 'siid': 2, 'piid': 4, 'code': 0, 'value': 0},
        ]
        """
        self.data = data

    @property
    def is_on(self) -> bool:
        """True if the device is turned on."""
        return self.data["power"]

    @property
    def power(self) -> str:
        """Current power state."""
        return "on" if self.is_on else "off"

    @property
    def brightness(self) -> int:
        """brightness"""
        return self.data["brightness"]

    @property
    def color_temperature(self) -> int:
        """Color temperature."""
        return self.data["color_temperature"]

    @property
    def mode(self) -> OperationCeilingMode:
        """Current operation mode."""
        return OperationCeilingMode(self.data["mode"])


class YeelightLampMiot(MiotDevice):
    """Main class representing the air conditioner which uses MIoT protocol."""

    _mappings = _MAPPINGS

    @command(
        default_output=format_output(
            "",
            "Power: {result.power}\n"
            "Brightness: {result.brightness}\n"
            "Color Temperature: {result.color_temperature} ℃\n"
            "Mode: {result.mode}\n"
        )
    )
    def status(self) -> YeelightLampMiotStatus:
        """Retrieve properties."""

        return YeelightLampMiotStatus(
            {
                prop["did"]: prop["value"] if prop["code"] == 0 else None
                for prop in self.get_properties_for_mapping()
            }
        )

    @command(default_output=format_output("Powering on"))
    def on(self):
        """Power on."""
        return self.set_property("power", True)

    @command(default_output=format_output("Powering off"))
    def off(self):
        """Power off."""
        return self.set_property("power", False)

    @command(
        click.argument("brightness", type=int),
        default_output=format_output(
            "Setting brightness to {brightness}"
        ),
    )
    def set_brightness(self, brightness: int):
        """Set Color temperature."""
        if (
            brightness < 1
            or brightness > 100
        ):
            raise ValueError("Invalid brightness: %s" % brightness)
        return self.set_property("brightness", brightness)

    @command(
        click.argument("color_temperature", type=int),
        default_output=format_output(
            "Setting color temperature to {color_temperature}"
        ),
    )
    def set_color_temperature(self, color_temperature: int):
        """Set Color temperature."""
        if (
            color_temperature < 2700
            or color_temperature > 6500
        ):
            raise ValueError("Invalid color temperature: %s" % color_temperature)
        return self.set_property("color_temperature", color_temperature)

    @command(
        click.argument("mode", type=EnumType(OperationLampMode)),
        default_output=format_output("Setting operation mode to '{mode.value}'"),
    )
    def set_mode(self, mode: OperationLampMode):
        """Set operation mode."""
        return self.set_property("mode", mode.value)

    
    def set_power(self, power: str):
        if power == 'on':
            return self.on()
        elif power == 'off':
            return self.off()
        else:
            raise KeyError("Please set on/off")
        
    def show_status(self):
        value_mapping = {
            "power": {False: "off", True: "on"},
            "mode": {0: "Reading", 1: "Computer", 2: "Night_Reading", 3: "Anti_blue", 4: "Effective_Work", 5: "Candle", 6: "Twinkle"}
        }
        status = self.status().data
        new_status = {}
        for key,value in status.items():
            try:
                new_status[key] = value_mapping[key][value]
            except:
                new_status[key] = value
        return new_status
        
    def show_actions(self):
        actions = [
            {"action": "power", "description": "set the power on/off.", "choices": {"on": "description: power on.", "off": "description: power off."}},
            {"action": "brightness", "description": "Change the brightness of light.", "choices": {"1-100": "description: please return an integer between 1 and 100."}},
            {"action": "color_temperature", "description": "Set Color temperature for light.", "choices": {"2700-6500": "description: please return an integer between 2700 and 6500."}},
            {"action": "mode", "description": "set the mode of light", "choices": {
                "Reading": "description: This mode is more suitable for reading books.", 
                "Computer": "description: This mode is more suitable for electronic devices.", 
                "Night_Reading": "description: This mode is more suitable for reading books at night.", 
                "Anti_blue": "description: This mode is better for the eyes.", 
                "Effective_Work": "description: This mode helps to improve work efficiency.", 
                "Candle": "description: This mode simulates Candle and has more atmosphere.", 
                "Twinkle": "description: This mode is very bright"
            }}
        ]
        return actions
    
    def execute(self, action, value):
        
        value_mapping = {
            "power": {
                "on": ["on"],
                "off": ["off"]
            },
            "brightness": {
                str(k): [int(k)] 
                for k in range(1,101)
            },
            "color_temperature": {
                str(k): [int(k)] 
                for k in range(2700,6501)
            },
            "mode": {
                "Reading": [OperationLampMode.Reading, 80, 6000], 
                "Computer": [OperationLampMode.Computer, 90, 5000], 
                "Night_Reading": [OperationLampMode.Night_Reading, 80, 4000], 
                "Anti_blue": [OperationLampMode.Anti_blue, 70, 4500], 
                "Effective_Work": [OperationLampMode.Effective_Work, 90, 6000], 
                "Candle": [OperationLampMode.Candle, 30, 2700], 
                "Twinkle": [OperationLampMode.Twinkle, 100, 6500]
            },
        }
    
        action_mapping = {
            "power": [self.set_power],
            "brightness": [self.set_brightness],
            "color_temperature": [self.set_color_temperature],
            "mode": [self.set_mode, self.set_brightness, self.set_color_temperature]
        }

        new_action = action_mapping[action]
        new_value = value_mapping[action][value]
        for a,v in zip(new_action, new_value):
            a(v)
       
            
class YeelightCeilingMiot(MiotDevice):
    """Main class representing the air conditioner which uses MIoT protocol."""

    _mappings = _MAPPINGS

    @command(
        default_output=format_output(
            "",
            "Power: {result.power}\n"
            "Brightness: {result.brightness}\n"
            "Color Temperature: {result.color_temperature} ℃\n"
            "Mode: {result.mode}\n"
        )
    )
    def status(self) -> YeelightCeilingMiotStatus:
        """Retrieve properties."""

        return YeelightCeilingMiotStatus(
            {
                prop["did"]: prop["value"] if prop["code"] == 0 else None
                for prop in self.get_properties_for_mapping()
            }
        )

    @command(default_output=format_output("Powering on"))
    def on(self):
        """Power on."""
        return self.set_property("power", True)

    @command(default_output=format_output("Powering off"))
    def off(self):
        """Power off."""
        return self.set_property("power", False)

    @command(
        click.argument("brightness", type=int),
        default_output=format_output(
            "Setting brightness to {brightness}"
        ),
    )
    def set_brightness(self, brightness: int):
        """Set Color temperature."""
        if (
            brightness < 1
            or brightness > 100
        ):
            raise ValueError("Invalid brightness: %s" % brightness)
        return self.set_property("brightness", brightness)

    @command(
        click.argument("color_temperature", type=int),
        default_output=format_output(
            "Setting color temperature to {color_temperature}"
        ),
    )
    def set_color_temperature(self, color_temperature: int):
        """Set Color temperature."""
        if (
            color_temperature < 2700
            or color_temperature > 6500
        ):
            raise ValueError("Invalid color temperature: %s" % color_temperature)
        return self.set_property("color_temperature", color_temperature)

    @command(
        click.argument("mode", type=EnumType(OperationCeilingMode)),
        default_output=format_output("Setting operation mode to '{mode.value}'"),
    )
    def set_mode(self, mode: OperationCeilingMode):
        """Set operation mode."""
        return self.set_property("mode", mode.value)

    
    def set_power(self, power: str):
        if power == 'on':
            return self.on()
        elif power == 'off':
            return self.off()
        else:
            raise KeyError("Please set on/off")
        
    def show_status(self):
        value_mapping = {
            "power": {False: "off", True: "on"},
            "mode": {1: "Day", 2: "Night"}
        }
        status = self.status().data
        new_status = {}
        for key,value in status.items():
            try:
                new_status[key] = value_mapping[key][value]
            except:
                new_status[key] = value
        return new_status
        
    def show_actions(self):
        actions = [
            {"action": "power", "description": "set the power on/off.", "choices": {"on": "description: power on.", "off": "description: power off."}},
            {"action": "brightness", "description": "Change the brightness of light.", "choices": {"1-100": "description: please return an integer between 1 and 100."}},
            {"action": "color_temperature", "description": "Set Color temperature for light.", "choices": {"2700-6500": "description: please return an integer between 2700 and 6500."}},
            {"action": "mode", "description": "set the mode of light", "choices": {
                "Day": "description: This mode is more suitable for daytime.", 
                "Night": "description: This mode is more suitable for night."
            }}
        ]
        return actions
    
    def execute(self, action, value):
        
        value_mapping = {
            "power": {
                "on": ["on"],
                "off": ["off"]
            },
            "brightness": {
                str(k): [int(k)] 
                for k in range(1,101)
            },
            "color_temperature": {
                str(k): [int(k)] 
                for k in range(2700,6501)
            },
            "mode": {
                "day": [OperationCeilingMode.Day, 70, 6000], 
                "night": [OperationCeilingMode.Night, 90, 5000]
            },
        }
    
        action_mapping = {
            "power": [self.set_power],
            "brightness": [self.set_brightness],
            "color_temperature": [self.set_color_temperature],
            "mode": [self.set_mode, self.set_brightness, self.set_color_temperature]
        }

        new_action = action_mapping[action]
        new_value = value_mapping[action][str(value).lower()]
        for a,v in zip(new_action, new_value):
            a(v)