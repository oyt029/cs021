import enum
import copy
import logging
from datetime import timedelta
from typing import Any, Dict

import click

from miio import DeviceStatus
from miio.click_common import EnumType, command, format_output

from device_simulation.modified_miio.miot_device import MiotDevice

_LOGGER = logging.getLogger(__name__)

SUPPORTED_MODELS = [
    "xiaomi.aircondition.mc1",
    "xiaomi.aircondition.mc2",
    "xiaomi.aircondition.mc4",
    "xiaomi.aircondition.mc5",
]



_MAPPING = {
    # Source http://miot-spec.org/miot-spec-v2/instance?type=urn:miot-spec-v2:device:air-conditioner:0000A004:xiaomi-mc4:1
    # Air Conditioner (siid=2)
    "power": {"siid": 2, "piid": 1},
    "mode": {"siid": 2, "piid": 2},
    "target_temperature": {"siid": 2, "piid": 4},
    "eco": {"siid": 2, "piid": 7},
    "heater": {"siid": 2, "piid": 9},
    "dryer": {"siid": 2, "piid": 10},
    "sleep_mode": {"siid": 2, "piid": 11},
    # Fan Control (siid=3)
    "fan_speed": {"siid": 3, "piid": 2},
    "vertical_swing": {"siid": 3, "piid": 4},
    # Environment (siid=4)
    "temperature": {"siid": 4, "piid": 7},
    # Alarm (siid=5)
    "buzzer": {"siid": 5, "piid": 1},
    # Indicator Light (siid=6)
    "led": {"siid": 6, "piid": 1},
    # Electricity (siid=8)
    "electricity": {"siid": 8, "piid": 1},
    # Maintenance (siid=9)
    "clean": {"siid": 9, "piid": 1},
    "running_duration": {"siid": 9, "piid": 5},
    # Enhance (siid=10)
    "fan_speed_percent": {"siid": 10, "piid": 1},
    "timer": {"siid": 10, "piid": 3},
}

_MAPPINGS = {model: _MAPPING for model in SUPPORTED_MODELS}


CLEANING_STAGES = [
    "Stopped",
    "Condensing water",
    "Frosting the surface",
    "Defrosting the surface",
    "Drying",
]


class CleaningStatus(DeviceStatus):
    def __init__(self, status: str):
        """Auto clean mode indicator.

        Value format: <int>,<int>,<int>,<int>
        Integer 1: whether auto cleaning mode started.
        Integer 2: current progress in percent.
        Integer 3: which stage it is currently under (see CLEANING_STAGE list).
        Integer 4: if current operation could be cancelled.

        Example auto clean indicator 1: 0,100,0,1
        indicates the auto clean mode has finished or not started yet.
        Example auto clean indicator 2: 1,22,1,1
        indicates auto clean mode finished 22%, it is condensing water and can be cancelled.
        Example auto clean indicator 3: 1,72,4,0
        indicates auto clean mode finished 72%, it is drying and cannot be cancelled.

        Only write 1 or 0 to it would start or abort the auto clean mode.
        """
        self.status = [int(value) for value in status.split(",")]

    @property
    def cleaning(self) -> bool:
        return bool(self.status[0])

    @property
    def progress(self) -> int:
        return int(self.status[1])

    @property
    def stage(self) -> str:
        try:
            return CLEANING_STAGES[self.status[2]]
        except KeyError:
            return "Unknown stage"

    @property
    def cancellable(self) -> bool:
        return bool(self.status[3])


class OperationMode(enum.Enum):
    Cool = 2
    Dry = 3
    Fan = 4
    Heat = 5


class FanSpeed(enum.Enum):
    Auto = 0
    Level1 = 1
    Level2 = 2
    Level3 = 3
    Level4 = 4
    Level5 = 5
    Level6 = 6
    Level7 = 7


class TimerStatus(DeviceStatus):
    def __init__(self, status):
        """Countdown timer indicator.

        Value format: <int>,<int>,<int>,<int>
        Integer 1: whether the timer is enabled.
        Integer 2: countdown timer setting value in minutes.
        Integer 3: the device would be powered on (1) or powered off (0) after timeout.
        Integer 4: the remaining countdown time in minutes.

        Example timer value 1: 1,120,0,103
        indicates the device would be turned off after 120 minutes, remaining 103 minutes.
        Example timer value 2: 1,60,1,60
        indicates the device would be turned on after 60 minutes, remaining 60 minutes.
        Example timer value 3: 0,0,0,0
        indicates countdown timer not set.

        Write the first three integers would set the correct countdown timer.
        Also, if the countdown minutes set to 0, the timer would be disabled.
        """
        self.status = [int(value) for value in status.split(",")]

    @property
    def enabled(self) -> bool:
        return bool(self.status[0])

    @property
    def countdown(self) -> timedelta:
        return timedelta(minutes=self.status[1])

    @property
    def power_on(self) -> bool:
        return bool(self.status[2])

    @property
    def time_left(self) -> timedelta:
        return timedelta(minutes=self.status[3])


class AirConditionerMiotStatus(DeviceStatus):
    """Container for status reports from the air conditioner (MIoT)."""

    def __init__(self, data: Dict[str, Any]) -> None:
        """
        Response (MIoT format) of a Mi Smart Air Conditioner A (xiaomi.aircondition.mc4)
        [
            {'did': 'power', 'siid': 2, 'piid': 1, 'code': 0, 'value': False},
            {'did': 'mode', 'siid': 2, 'piid': 2, 'code': 0, 'value': 2},
            {'did': 'target_temperature', 'siid': 2, 'piid': 4, 'code': 0, 'value': 26.5},
            {'did': 'eco', 'siid': 2, 'piid': 7, 'code': 0, 'value': False},
            {'did': 'heater', 'siid': 2, 'piid': 9, 'code': 0, 'value': True},
            {'did': 'dryer', 'siid': 2, 'piid': 10, 'code': 0, 'value': True},
            {'did': 'sleep_mode', 'siid': 2, 'piid': 11, 'code': 0, 'value': False},
            {'did': 'fan_speed', 'siid': 3, 'piid': 2, 'code': 0, 'value': 0},
            {'did': 'vertical_swing', 'siid': 3, 'piid': 4, 'code': 0, 'value': True},
            {'did': 'temperature', 'siid': 4, 'piid': 7, 'code': 0, 'value': 28.4},
            {'did': 'buzzer', 'siid': 5, 'piid': 1, 'code': 0, 'value': False},
            {'did': 'led', 'siid': 6, 'piid': 1, 'code': 0, 'value': False},
            {'did': 'electricity', 'siid': 8, 'piid': 1, 'code': 0, 'value': 0.0},
            {'did': 'clean', 'siid': 9, 'piid': 1, 'code': 0, 'value': '0,100,1,1'},
            {'did': 'running_duration', 'siid': 9, 'piid': 5, 'code': 0, 'value': 151.0},
            {'did': 'fan_speed_percent', 'siid': 10, 'piid': 1, 'code': 0, 'value': 101},
            {'did': 'timer', 'siid': 10, 'piid': 3, 'code': 0, 'value': '0,0,0,0'}
        ]

        """
        self.data = data

    @property
    def is_on(self) -> bool:
        """True if the device is turned on."""
        return self.data["power"]

    @property
    def power(self) -> str:
        """Current power state."""
        return "on" if self.is_on else "off"

    @property
    def mode(self) -> OperationMode:
        """Current operation mode."""
        return OperationMode(self.data["mode"])

    @property
    def target_temperature(self) -> float:
        """Target temperature in Celsius."""
        return self.data["target_temperature"]

    @property
    def eco(self) -> bool:
        """True if ECO mode is on."""
        return self.data["eco"]

    @property
    def heater(self) -> bool:
        """True if aux heat mode is on."""
        return self.data["heater"]

    @property
    def dryer(self) -> bool:
        """True if aux dryer mode is on."""
        return self.data["dryer"]

    @property
    def sleep_mode(self) -> bool:
        """True if sleep mode is on."""
        return self.data["sleep_mode"]

    @property
    def fan_speed(self) -> FanSpeed:
        """Current Fan speed."""
        return FanSpeed(self.data["fan_speed"])

    @property
    def vertical_swing(self) -> bool:
        """True if vertical swing is on."""
        return self.data["vertical_swing"]

    @property
    def temperature(self) -> float:
        """Current ambient temperature in Celsius."""
        return self.data["temperature"]

    @property
    def buzzer(self) -> bool:
        """True if buzzer is on."""
        return self.data["buzzer"]

    @property
    def led(self) -> bool:
        """True if LED is on."""
        return self.data["led"]

    @property
    def electricity(self) -> float:
        """Power consumption accumulation in kWh."""
        return self.data["electricity"]

    @property
    def clean(self) -> CleaningStatus:
        """Auto clean mode indicator."""
        return CleaningStatus(self.data["clean"])

    @property
    def total_running_duration(self) -> timedelta:
        """Total running duration in hours."""
        return timedelta(hours=self.data["running_duration"])

    @property
    def fan_speed_percent(self) -> int:
        """Current fan speed in percent."""
        return self.data["fan_speed_percent"]

    @property
    def timer(self) -> TimerStatus:
        """Countdown timer indicator."""
        return TimerStatus(self.data["timer"])


class AirConditionerMiot(MiotDevice):
    """Main class representing the air conditioner which uses MIoT protocol."""

    _mappings = _MAPPINGS

    @command(
        default_output=format_output(
            "",
            "Power: {result.power}\n"
            "Mode: {result.mode}\n"
            "Target Temperature: {result.target_temperature} ℃\n"
            "ECO Mode: {result.eco}\n"
            "Heater: {result.heater}\n"
            "Dryer: {result.dryer}\n"
            "Sleep Mode: {result.sleep_mode}\n"
            "Fan Speed: {result.fan_speed}\n"
            "Vertical Swing: {result.vertical_swing}\n"
            "Room Temperature: {result.temperature} ℃\n"
            "Buzzer: {result.buzzer}\n"
            "LED: {result.led}\n"
            "Electricity: {result.electricity}kWh\n"
            "Clean: {result.clean}\n"
            "Running Duration: {result.total_running_duration}\n"
            "Fan percent: {result.fan_speed_percent}\n"
            "Timer: {result.timer}\n",
        )
    )
    def status(self) -> AirConditionerMiotStatus:
        """Retrieve properties."""

        return AirConditionerMiotStatus(
            {
                prop["did"]: prop["value"] if prop["code"] == 0 else None
                for prop in self.get_properties_for_mapping()
            }
        )

    @command(default_output=format_output("Powering on"))
    def on(self):
        """Power on."""
        return self.set_property("power", True)

    @command(default_output=format_output("Powering off"))
    def off(self):
        """Power off."""
        return self.set_property("power", False)

    @command(
        click.argument("mode", type=EnumType(OperationMode)),
        default_output=format_output("Setting operation mode to '{mode.value}'"),
    )
    def set_mode(self, mode: OperationMode):
        """Set operation mode."""
        return self.set_property("mode", mode.value)

    @command(
        click.argument("target_temperature", type=float),
        default_output=format_output(
            "Setting target temperature to {target_temperature}"
        ),
    )
    def set_target_temperature(self, target_temperature: float):
        """Set target temperature in Celsius."""
        if (
            target_temperature < 16.0
            or target_temperature > 31.0
            or target_temperature % 0.5 != 0
        ):
            raise ValueError("Invalid target temperature: %s" % target_temperature)
        return self.set_property("target_temperature", target_temperature)

    @command(
        click.argument("eco", type=bool),
        default_output=format_output(
            lambda eco: "Turning on ECO mode" if eco else "Turning off ECO mode"
        ),
    )
    def set_eco(self, eco: bool):
        """Turn ECO mode on/off."""
        return self.set_property("eco", eco)

    @command(
        click.argument("heater", type=bool),
        default_output=format_output(
            lambda heater: "Turning on heater" if heater else "Turning off heater"
        ),
    )
    def set_heater(self, heater: bool):
        """Turn aux heater mode on/off."""
        return self.set_property("heater", heater)

    @command(
        click.argument("dryer", type=bool),
        default_output=format_output(
            lambda dryer: "Turning on dryer" if dryer else "Turning off dryer"
        ),
    )
    def set_dryer(self, dryer: bool):
        """Turn aux dryer mode on/off."""
        return self.set_property("dryer", dryer)

    @command(
        click.argument("sleep_mode", type=bool),
        default_output=format_output(
            lambda sleep_mode: "Turning on sleep mode"
            if sleep_mode
            else "Turning off sleep mode"
        ),
    )
    def set_sleep_mode(self, sleep_mode: bool):
        """Turn sleep mode on/off."""
        return self.set_property("sleep_mode", sleep_mode)

    @command(
        click.argument("fan_speed", type=EnumType(FanSpeed)),
        default_output=format_output("Setting fan speed to {fan_speed}"),
    )
    def set_fan_speed(self, fan_speed: FanSpeed):
        """Set fan speed."""
        return self.set_property("fan_speed", fan_speed.value)

    @command(
        click.argument("vertical_swing", type=bool),
        default_output=format_output(
            lambda vertical_swing: "Turning on vertical swing"
            if vertical_swing
            else "Turning off vertical swing"
        ),
    )
    def set_vertical_swing(self, vertical_swing: bool):
        """Turn vertical swing on/off."""
        return self.set_property("vertical_swing", vertical_swing)

    @command(
        click.argument("led", type=bool),
        default_output=format_output(
            lambda led: "Turning on LED" if led else "Turning off LED"
        ),
    )
    def set_led(self, led: bool):
        """Turn led on/off."""
        return self.set_property("led", led)

    @command(
        click.argument("buzzer", type=bool),
        default_output=format_output(
            lambda buzzer: "Turning on buzzer" if buzzer else "Turning off buzzer"
        ),
    )
    def set_buzzer(self, buzzer: bool):
        """Set buzzer on/off."""
        return self.set_property("buzzer", buzzer)

    @command(
        click.argument("percent", type=int),
        default_output=format_output("Setting fan percent to {percent}%"),
    )
    def set_fan_speed_percent(self, fan_speed_percent):
        """Set fan speed in percent, should be  between 1 to 100 or 101(auto)."""
        if fan_speed_percent < 1 or fan_speed_percent > 101:
            raise ValueError("Invalid fan percent: %s" % fan_speed_percent)
        return self.set_property("fan_speed_percent", fan_speed_percent)

    @command(
        click.argument("minutes", type=int),
        click.argument("delay_on", type=bool),
        default_output=format_output(
            lambda minutes, delay_on: "Setting timer to delay on after "
            + str(minutes)
            + " minutes"
            if delay_on
            else "Setting timer to delay off after " + str(minutes) + " minutes"
        ),
    )
    def set_timer(self, minutes, delay_on):
        """Set countdown timer minutes and if it would be turned on after timeout.

        Set minutes to 0 would disable the timer.
        """
        return self.set_property(
            "timer", ",".join(["1", str(minutes), str(int(delay_on))])
        )

    @command(
        click.argument("clean", type=bool),
        default_output=format_output(
            lambda clean: "Begin auto cleanning" if clean else "Abort auto cleaning"
        ),
    )
    def set_clean(self, clean):
        """Start or abort clean mode."""
        return self.set_property("clean", str(int(clean)))
    
    def set_power(self, power):
        if power == 'on':
            return self.on()
        elif power == 'off':
            return self.off()
        else:
            raise KeyError("Please set on/off")
        
    def show_status(self):
        value_mapping = {
            "power": {False: "off", True: "on"},
            "mode": {2: "cool", 3: "dry", 4: "fan", 5: "heat"},
            "eco": {True: "on", False: "off"},
            "sleep_mode": {True: "on", False: "off"},
            "fan_speed": {0: "auto", 1: "level1", 2: "level2", 3: "level3", 4: "level4", 5: "level5", 6: "level6", 7: "level7"},
            "vertical_swing": {True: "on", False: "off"},
        }
        status = self.status().data
        for key in ['dryer', 'heater', 'temperature', 'buzzer', 'electricity', 'clean', 'running_duration', 'fan_speed_percent', 'timer', 'led']:
            status.pop(key, None)
        new_status = {}
        for key,value in status.items():
            try:
                new_status[key] = value_mapping[key][value]
            except:
                new_status[key] = value
        return new_status
        
    def show_actions(self):
        actions = [
            {"action": "power", "description": "set the power on/off.", "choices": {"on": "description: power on.", "off": "description: power off."}},
            {"action": "mode", "description": "set the mode of airconditioner", "choices": {"cool": "description: The air conditioner blows cold air.", "dry": "description: The air conditioner starts to dehumidify.", "fan": "description: The air conditioner starts blowing, it doesn't cool or heat.", "heat": "description: The air conditioner starts blowing hot air."}},
            {"action": "target_temperature", "description": "Set target temperature in Celsius.", "choices": {"17-31": "description: choose one from 17-31 Degree Celsius, only integer"}},
            {"action": "eco", "description": "Turn ECO mode on/off. ECO mode will reduce electricity consumption", "choices": {"on": "description: set ECO mode on.", "off": "description: set ECO mode off."}},
            {"action": "sleep_mode", "description": "Turn sleep mode on/off. sleep mode will change the fan speed and close the LED", "choices": {"on": "description: set sleep mode on, set led off", "off": "description: set sleep mode on, set led on."}},
            {"action": "fan_speed", "description": "Set fan speed. The higher level, the faster the fan speed.", "choices": {"auto": "description: Automatic fan speed adjustment.", "level1": "description: level1 fan speed", "level2": "description: level2 fan speed", "level3": "description: level3 fan speed", "level4": "description: level4 fan speed", "level5": "description: level5 fan speed", "level6": "description: level6 fan speed", "level7": "description: level7 fan speed"}},
            {"action": "vertical_swing", "description": "Turn vertical swing on/off.", "choices": {"on": "description: set vertical swing on", "off": "description: set vertical swing off"}}
        ]
        return actions
    
    def execute(self, action, value):
        
        value_mapping = {
            "power": {
                "on": ["on"],
                "off": ["off"]
            },
            "mode": {
                "cool": [OperationMode.Cool, False, False],
                "dry": [OperationMode.Dry, False, True],
                "fan": [OperationMode.Fan, False, False],
                "heat": [OperationMode.Heat, True, False]
            },
            "target_temperature": {
                str(k): [float(k)] 
                for k in range(17,31)
            },
            "eco": {
                "on": [True, False], 
                "off": [False, True]
            },
            "sleep_mode": {
                "on": [True, False],
                "off": [False, True]
            },
            "fan_speed": {
                "auto": [FanSpeed.Auto],
                "level1": [FanSpeed.Level1],
                "level2": [FanSpeed.Level2],
                "level3": [FanSpeed.Level3],
                "level4": [FanSpeed.Level4],
                "level5": [FanSpeed.Level5],
                "level6": [FanSpeed.Level6],
                "level7": [FanSpeed.Level7]
            },
            "vertical_swing": {
                "on": [True],
                "off": [False]
            }
        }
    
        action_mapping = {
            "power": [self.set_power],
            "mode": [self.set_mode, self.set_heater, self.set_dryer],
            "target_temperature": [self.set_target_temperature],
            "eco": [self.set_eco, self.set_led],
            "sleep_mode": [self.set_sleep_mode, self.set_led],
            "fan_speed": [self.set_fan_speed],
            "vertical_swing": [self.set_vertical_swing]    
        }

        new_action = action_mapping[action]
        new_value = value_mapping[action][str(value).lower()]
        for a,v in zip(new_action, new_value):
            a(v)