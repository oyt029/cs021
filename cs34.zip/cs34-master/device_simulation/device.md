# Usage
1. pip install -r requirements.txt
2. python device_simulation/run_server.py