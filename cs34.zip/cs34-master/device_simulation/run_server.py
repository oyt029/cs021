# from device_simulation.server.server_manager import ServerManager
# from device_simulation.server.device_manager import DeviceManager
# from device_simulation.util import load_json_file
from server.server_manager import ServerManager
from server.device_manager import DeviceManager
from util import load_json_file


def main():
    # load devices info
    try:
        devices = load_json_file("device_simulation/devices.json")
    except:
        devices = load_json_file("devices.json")
    
    # create dev_manager & server manager
    dev_manager = DeviceManager()
    server_manager = ServerManager()
    for dev in devices:
        dev_manager.register_device(dev['device_name'], dev['device_info_path'], dev['device_type'], dev['ip'], dev['port'])
    print("All devices: ")
    print(dev_manager.show_registered_devices())
    print("\nStart Server")
    server_manager.start(dev_manager.get_registered_devices())

if __name__ == "__main__":
    main()