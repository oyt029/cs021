import re
from typing import Optional
from datetime import datetime
from datetime import timedelta
from typing import Any, Dict, List, Optional, Tuple

from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate, ChatPromptTemplate, HumanMessagePromptTemplate
from langchain.schema.language_model import BaseLanguageModel
from langchain.schema.messages import SystemMessage
from langchain.agents import initialize_agent
from langchain_experimental.generative_agents.memory import GenerativeAgentMemory
from langchain_experimental.pydantic_v1 import BaseModel, Field
from langchain_experimental.plan_and_execute.planners.base import LLMPlanner
from langchain_experimental.plan_and_execute.schema import Plan

from agent_simulation.prompts import AgentPrompt
from agent_simulation.tools import controlDevice, getEnvData, getDeviceController
from agent_simulation.utils import PlanningOutputParser
from home_bot.tools import controlHomeBot

class GenerativeAgent(BaseModel):
    """A representation of a generative agent, which is a character with memory and innate characteristics."""

    # Class attributes with brief comments
    name: str  # The character's name.
    age: Optional[int] = None  # Optional age of the character.
    traits: str = "N/A"  # Permanent traits of the character.
    status: str  # Dynamic status of the character.
    memory: GenerativeAgentMemory  # The memory model of the agent, combining relevance, recency, and importance.
    llm: BaseLanguageModel  # The underlying language model the agent uses.
    verbose: bool = False  # Flag to indicate verbosity.
    summary: str = ""  # Current self-summary of the agent.
    summary_refresh_seconds: int = 3600  # Time interval for regenerating the summary.
    last_refreshed: datetime = Field(default_factory=datetime.now)  # The last time the summary was updated.
    daily_summaries: List[str] = Field(default_factory=list)  # List of daily summaries of the agent's actions.

    global tools
    tools = [controlDevice, getEnvData, getDeviceController, controlHomeBot]
    # tools = [controlDevice, getEnvData, getDeviceController]
    # tools = [getEnvData, controlHomeBot]

    class Config:
        """Configuration settings for the Pydantic object."""
        arbitrary_types_allowed = True

    @staticmethod
    def _parse_list(text: str) -> List[str]:
        """Converts a text with newline-separated lines into a list of strings."""
        lines = re.split(r"\n", text.strip())
        return [re.sub(r"^\s*\d+\.\s*", "", line).strip() for line in lines]

    def tool_chain(self) -> LLMChain:
        """Utilizes the LLMChain to generate a response given a prompt."""
        # return LLMChain(llm=self.llm, prompt=prompt, verbose=self.verbose, memory=self.memory)
        # return initialize_agent(tools, self.llm, memory=self.memory, verbose=self.verbose, 
        #                         return_intermediate_steps=True, handle_parsing_errors=True).run(prompt)
        return initialize_agent(tools, self.llm, memory=self.memory, verbose=self.verbose, 
                                return_intermediate_steps=True, handle_parsing_errors=True)
    
    def chain(self, prompt: PromptTemplate) -> LLMChain:
        """Utilizes the LLMChain to generate a response given a prompt."""
        return LLMChain(llm=self.llm, prompt=prompt, verbose=self.verbose, memory=self.memory)

    # ==== The following code summarises the agent's observation. ==== #
    def _get_entity_from_observation(self, observation: str) -> str:
        prompt = PromptTemplate.from_template(
            "What is the observed entity in the following observation? {observation}"
            + "\nEntity="
        )
        return self.chain(prompt).run(observation=observation).strip()

    def _get_entity_action(self, observation: str, entity_name: str) -> str:
        prompt = PromptTemplate.from_template(
            "What is the {entity} doing in the following observation? {observation}"
            + "\nThe {entity} is"
        )
        return (
            self.chain(prompt).run(entity=entity_name, observation=observation).strip()
        )

    def summarize_related_memories(self, observation: str) -> str:
        """Summarize memories that are most relevant to an observation."""
        prompt = PromptTemplate.from_template(
            """
            {q1}?
            Context from memory:
            {relevant_memories}
            Relevant context: 
            """)
        
        entity_name = self._get_entity_from_observation(observation)
        entity_action = self._get_entity_action(observation, entity_name)
        q1 = f"What is the relationship between {self.name} and {entity_name}"
        q2 = f"{entity_name} is {entity_action}"
        return self.chain(prompt=prompt).run(q1=q1, queries=[q1, q2]).strip()
    # ==== The above code summarises the agent's observation. ==== #

    
    # ==== The following code checks the environment status summaries for the agent. ==== #
    def _get_env_status(self) -> str:
        """Extracts the main entity from an observation text."""

        prompt, output_parser, format_instructions = AgentPrompt.get_env_objects()

        final_prompt = PromptTemplate(input_variables=["getEnvData"],
                                      partial_variables={"format_instructions": format_instructions},
                                      template=prompt).format(getEnvData=getEnvData)
        
        # response = self.tool_chain(final_prompt)

        return output_parser.parse(self.tool_chain(final_prompt))
        # return output_parser.parse(response), response["intermediate_steps"]

    def change_env(self, preference: list, curr_person: str, curr_room: str, curr_time: str, curr_task: str, smart_devices: list) -> str:
        """Identifies the action of a specific entity from an observation."""
        # prompt = PromptTemplate.from_template(
        #     "What are the {objects} status in the following observation? {observation}" + "\nThe {objects} are"
        # )
        # return self.chain(prompt).run(objects=object_name, observation=observation).strip()
        prompt, output_parser, format_instructions = AgentPrompt.change_env_status()

        # only control homebot
        # final_prompt = PromptTemplate(input_variables=["preference", "room", "name", "time", "task", "smart_devices", "getEnvData", "controlHomeBot"],
        #                               partial_variables={"format_instructions": format_instructions},
        #                               template=prompt).format(preference=preference,
        #                                                       room=curr_room,
        #                                                       name=curr_person,
        #                                                       time=curr_time,
        #                                                       task=curr_task,
        #                                                       smart_devices=smart_devices,
        #                                                       getEnvData=getEnvData, 
        #                                                       controlHomeBot=controlHomeBot)

        # both homebot and control devices
        final_prompt = PromptTemplate(input_variables=["preference", "room", "name", "time", "task", "smart_devices", "getEnvData", "controlDevice", "getDeviceController", "controlHomeBot"],
                                      partial_variables={"format_instructions": format_instructions},
                                      template=prompt).format(preference=preference,
                                                              room=curr_room,
                                                              name=curr_person,
                                                              time=curr_time,
                                                              task=curr_task,
                                                              smart_devices=smart_devices,
                                                              getEnvData=getEnvData, 
                                                              controlDevice=controlDevice,
                                                              getDeviceController=getDeviceController,
                                                              controlHomeBot=controlHomeBot)

        # no homebot
        # final_prompt = PromptTemplate(input_variables=["preference", "room", "name", "time", "task", "smart_devices", "getEnvData", "controlDevice", "getDeviceController"],
        #                               partial_variables={"format_instructions": format_instructions},
        #                               template=prompt).format(preference=preference,
        #                                                       room=curr_room,
        #                                                       name=curr_person,
        #                                                       time=curr_time,
        #                                                       task=curr_task,
        #                                                       smart_devices=smart_devices,
        #                                                       getEnvData=getEnvData, 
        #                                                       controlDevice=controlDevice,
        #                                                       getDeviceController=getDeviceController)

        try:
            agent = self.tool_chain()
            response = agent(final_prompt)
        except:
            agent = self.tool_chain()
            response = agent(final_prompt)
            
        # print(response.keys())
        # return output_parser.parse(self.tool_chain(final_prompt))
        try:
            return output_parser.parse(response["output"]), response["intermediate_steps"]
        except:
            return response["output"], response["intermediate_steps"]

    #TODO: Update the code for the summary of environment change and reflection
    def summarize_env(self) -> str:
        """Summarizes the memories that are most related to a given observation."""
        prompt = PromptTemplate.from_template("""
            Here is the latest environment information: {q1}
            Context from memory:
            {relevant_memories}
            Relevant context: 
        """)
        env_status = self._get_env_status()
        # object_status = self._get_entity_action(observation, object_name)
        q1 = f"What is the current environment like?\n {env_status}"
        # q2 = f"{object_name} is {object_status}"
        return self.chain(prompt=prompt).run(q1=q1, queries=[q1]).strip()
    # ==== The above code checks the environment status summaries for the agent. ==== #

    # ==== The following code let the agent make a plan. ==== #
    def _load_chat_planner(self, prompt: PromptTemplate, system_prompt: str = AgentPrompt.PLAN_SYSTEM_PROMPT) -> LLMPlanner:
        """
        Load a chat planner.

        Args:
            llm: Language model.
            system_prompt: System prompt.

        Returns:
            LLMPlanner
        """
        prompt_template = ChatPromptTemplate.from_messages(
            [
                SystemMessage(content=system_prompt),
                HumanMessagePromptTemplate.from_template("{input}"),
            ]
        )
        llm_chain = LLMChain(llm=self.llm, prompt=prompt_template)

        llm_planner = LLMPlanner(
            llm_chain=llm_chain,
            output_parser=PlanningOutputParser(),
            stop=["<END_OF_PLAN>"],
        )
        # Generate the response
        response = llm_planner.llm_chain(prompt)['text']

        # Manually remove the "<END_OF_PLAN>"
        if "<END_OF_PLAN>" in response:
            response = response.split("<END_OF_PLAN>")[0]

        return response

        # return LLMPlanner(
        #     llm_chain=llm_chain,
        #     output_parser=PlanningOutputParser(),
        #     stop=["<END_OF_PLAN>"],
        # ).llm_chain(prompt)['text']
    
    # def make_plan(self, observation: str) -> Plan:
    #     """Makes a plan for a given observation."""
    #     prompt = PromptTemplate.from_template("""{observation}
    #                                           Please make a plan and specify the rooms and times that are suitable for the planned tasks.
    #                                           Please choose a single room from list below: (bedroom is for Tommie and main_bedroom with tv is for Emma and Jason.)
    #                                           [main_bedroom, bedroom, bathroom, kitchen, living_room, front_door]
    #                                           Time should be in 24-Hour time format, do not use am/pm.
    #                                           Your plan must be given as the following "FORMAT", without any thinking steps:
    #                                           FORMAT
    #                                           [Srat time - End time] The content of the plan - room_name """).format(observation=observation)
    #
    #     return self._load_chat_planner(prompt=prompt)

    def make_plan(self, observation: str) -> LLMPlanner:
        """
        Makes a plan for a given observation.

        Args:
            observation: Observation string describing the current situation.
            days_offset: The number of days offset from the start date.

        Returns:
            Plan: Plan object (or string) generated by the planner.
        """
        start_date = "2023-09-01"  # 初始日期，可以根据需要调整

        # 计算当前日期偏移
        #current_date = (datetime.strptime(start_date, "%Y-%m-%d") + timedelta(days=days_offset)).strftime("%Y-%m-%d")

        # 使用指定的计划提示模板生成带有当前日期的提示
        prompt = f"""{observation}
                              Please make a plan and specify the rooms and times that are suitable for the planned tasks.
                              Please choose a single room from list below: (bedroom is for Tommie and main_bedroom with tv is for Emma and Jason.)
                              [main_bedroom, bedroom, bathroom, kitchen, living_room, front_door]
                              Time should be in 24-Hour time format, do not use am/pm.
                              Your plan must be given as the following "FORMAT", without any thinking steps:
                              FORMAT
                              [{start_date} Start time - End time] The content of the plan - room_name"""

        # 调用加载聊天规划器方法，生成并获取计划响应
        return self._load_chat_planner(prompt=prompt)

    def make_plan_with_previous(self, observation: str, days_offset: int = 0, is_morning: bool = True) -> LLMPlanner:
        """
        Makes a plan for a given observation.

        Args:
            observation: Observation string describing the current situation.
            days_offset: The number of days offset from the start date.

        Returns:
            Plan: Plan object (or string) generated by the planner.
        """
        start_date = "2023-09-01"
        # Calculate the current date with the offset
        current_date = (datetime.strptime(start_date, "%Y-%m-%d") + timedelta(days=days_offset)).strftime("%Y-%m-%d")

        # Choose appropriate prompt template based on whether it's morning or evening
        # if is_morning:
        #     prompt = morning_prompt_template.format(date=current_date, previous_plan=previous_plan)
        # else:
        #     prompt = evening_prompt_template.format(date=current_date, previous_plan=previous_plan, lifestyle=lifestyle)

        # Add common instructions to the prompt
        prompt = f"""{observation}
                              Please make a plan and specify the rooms and times that are suitable for the planned tasks.
                              Please choose a single room from list below: (bedroom is for Tommie and main_bedroom with tv is for Emma and Jason.)
                              [main_bedroom, bedroom, bathroom, kitchen, living_room, front_door]
                              Time should be in 24-Hour time format, do not use am/pm.
                              Your plan must be given as the following "FORMAT", without any thinking steps:
                              FORMAT
                              [{current_date} Start time - End time] The content of the plan - room_name"""
        # Call the method that loads the chat planner and returns the plan
        return self._load_chat_planner(prompt=prompt)


    # ==== The above code let the agent make a plan. ==== #
    
    def _generate_reaction(self, observation: str, suffix: str, now: Optional[datetime] = None) -> str:
        """React to a given observation or dialogue act."""
        prompt = PromptTemplate.from_template(
            "{agent_summary_description}"
            + "\nIt is {current_time}."
            + "\n{agent_name}'s status: {agent_status}"
            + "\nSummary of relevant context from {agent_name}'s memory:"
            + "\n{relevant_memories}"
            + "\nMost recent observations: {most_recent_memories}"
            + "\nObservation: {observation}"
            + "\n\n"
            + suffix
        )
        agent_summary_description = self.get_summary(now=now)
        relevant_memories_str = self.summarize_related_memories(observation)
        current_time_str = (
            datetime.now().strftime("%B %d, %Y, %I:%M %p")
            if now is None
            else now.strftime("%B %d, %Y, %I:%M %p")
        )
        kwargs: Dict[str, Any] = dict(
            agent_summary_description=agent_summary_description,
            current_time=current_time_str,
            relevant_memories=relevant_memories_str,
            agent_name=self.name,
            observation=observation,
            agent_status=self.status,
        )
        consumed_tokens = self.llm.get_num_tokens(
            prompt.format(most_recent_memories="", **kwargs)
        )
        kwargs[self.memory.most_recent_memories_token_key] = consumed_tokens
        return self.chain(prompt=prompt).run(**kwargs).strip()

    def _clean_response(self, text: str) -> str:
        return re.sub(f"^{self.name} ", "", text.strip()).strip()

    # ==== The following code let the agent react with the enviroment status. ==== #
    # TODO: Update the code for the environment and reflection
    def generate_reaction(self, observation: str, now: Optional[datetime] = None) -> Tuple[bool, str]:
        """React to a given observation."""
        call_to_action_template = (
            "Should {agent_name} react to the observation, and if so,"
            + " what would be an appropriate reaction? Respond in one line."
            + ' If the action is to engage in dialogue, write:\nSAY: "what to say"'
            + "\notherwise, write:\nREACT: {agent_name}'s reaction (if anything)."
            + "\nEither do nothing, react, or say something but not both.\n\n"
        )
        full_result = self._generate_reaction(
            observation, call_to_action_template, now=now
        )
        result = full_result.strip().split("\n")[0]
        # AAA
        self.memory.save_context(
            {},
            {
                self.memory.add_memory_key: f"{self.name} observed "
                f"{observation} and reacted by {result}",
                self.memory.now_key: now,
            },
        )
        if "REACT:" in result:
            reaction = self._clean_response(result.split("REACT:")[-1])
            return False, f"{self.name} {reaction}"
        if "SAY:" in result:
            said_value = self._clean_response(result.split("SAY:")[-1])
            return True, f"{self.name} said {said_value}"
        else:
            return False, result

    # ==== The above code let the agent have the conversation with another agent. ==== #
    def generate_dialogue_response(
        self, observation: str, now: Optional[datetime] = None) -> Tuple[bool, str]:
        """React to a given observation."""
        call_to_action_template = (
            """What would {agent_name} say? Please try to end conversation.
            To end the conversation, write:
            ```GOODBYE: (at beginning) "what to say for ending"```. 
            Otherwise to continue the conversation, write:
            ```SAY: "what to say next"```\n\n"""
        )
        full_result = self._generate_reaction(
            observation, call_to_action_template, now=now
        )
        result = full_result.strip().split("\n")[0]
        if "GOODBYE:" in result.lower():
            farewell = self._clean_response(result.split("GOODBYE:")[-1])
            self.memory.save_context(
                {},
                {
                    self.memory.add_memory_key: f"{self.name} observed "
                    f"{observation} and said {farewell}",
                    self.memory.now_key: now,
                },
            )
            return False, f"{self.name} said {farewell}"
        if "SAY:" in result:
            response_text = self._clean_response(result.split("SAY:")[-1])
            self.memory.save_context(
                {},
                {
                    self.memory.add_memory_key: f"{self.name} observed "
                    f"{observation} and said {response_text}",
                    self.memory.now_key: now,
                },
            )
            return True, f"{self.name} said {response_text}"
        else:
            return False, result


    # ==== The following code checks the agent memories for summary. ==== #
    # ==== Adopted directly from LangChain ==== #
    def _compute_agent_summary(self) -> str:
        """Computes a descriptive summary for the agent based on its memories."""
        prompt = PromptTemplate.from_template(
            "How would you summarize {name}'s core preference given the"
            + " following statements:\n"
            + "{name}'s traits:\n{traits}\n"
            + "{name}'s memories:\n{relevant_memories}\n"
            + "Do not embellish."
            + "\n\nSummary: "
        )
        # The agent seeks to think about their core characteristics.
        return (
            self.chain(prompt)
            .run(name=self.name, traits=self.traits, queries=[f"{self.name}'s core preference"])
            .strip()
        )
    
    def get_summary(self, force_refresh: bool = False, now: Optional[datetime] = None) -> str:
        """Returns a current summary of the agent, refreshing it if needed."""
        # This function checks if the summary needs to be refreshed and then retrieves or computes it.
        current_time = datetime.now() if now is None else now
        since_refresh = (current_time - self.last_refreshed).seconds
        if (
            not self.summary
            or since_refresh >= self.summary_refresh_seconds
            or force_refresh
        ):
            self.summary = self._compute_agent_summary()
            self.last_refreshed = current_time
        age = self.age if self.age is not None else "N/A"
        return (
            f"Name: {self.name} (age: {age})"
            + f"\nInnate traits: {self.traits}"
            + f"\n{self.summary}"
        )
    
    def get_full_header(self, force_refresh: bool = False, now: Optional[datetime] = None) -> str:
        """Generates a full header for the agent including its summary, current status, and time."""
        # This function constructs a detailed header for the agent, which can be used in dialogues or interactions.
        """Return a full header of the agent's status, summary, and current time."""
        now = datetime.now() if now is None else now
        summary = self.get_summary(force_refresh=force_refresh, now=now)
        current_time_str = now.strftime("%B %d, %Y, %I:%M %p")
        return (
            f"{summary}\nIt is {current_time_str}.\n{self.name}'s status: {self.status}"
        )
    # ==== The above code checks the agent memories for summary. ==== #