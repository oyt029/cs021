# from langchain import PromptTemplate
from langchain.chains.question_answering.map_rerank_prompt import output_parser
from langchain.output_parsers import StructuredOutputParser, ResponseSchema
from langchain_core.output_parsers import JsonOutputParser


# from typing import Optional

class AgentPrompt():
    # Prompt for the agent
    PLAN_SYSTEM_PROMPT = (
        "Let's first understand the problem and devise a plan to solve the problem."
        "Please output the plan starting with the header 'Plan:' "
        "and then followed by a numbered list of steps. "
        "Please make the plan the minimum number of steps required "
        "to accurately complete the task."
        "At the end of your plan, say '<END_OF_PLAN>'")

    # EMMA_MORNINGS_PROMPT = (
    #     "It's 6am in the morning, you are Emma."
    #     "You are a doctor just waking up in your room."
    #     "You need to plan your morning routine and leave your home before 7:30am."
    # )
    #
    # EMMA_EVENINGS_PROMPT = (
    #     "It's 5pm in the evening, you are Emma."
    #     "You are a doctor just coming back home from work."
    #     "You need to plan your evening routine and here is your lifestyle: {}"
    #     "Once you go to bed, you will sleep until the next morning."
    # )
    #
    # EMMA_NEXT_DAY_MORNINGS_PROMPT = (
    #     "It's 6am in the morning, you are Emma. "
    #     "You are a doctor just waking up in your room. "
    #     "Yesterday, you accomplished the following plans: {}. "
    #     "You need to plan your morning routine and leave your home before 7:30am. "
    #     "Once you leave home, you will start your work at the hospital."
    # )
    #
    # EMMA_NEXT_DAY_EVENINGS_PROMPT = (
    #     "It's 5pm in the evening, you are Emma. "
    #     "You are a doctor just coming back home from work. "
    #     "Yesterday, you accomplished the following plans: {}. "
    #     "You need to plan your evening routine and here is your lifestyle: {}. "
    #     "Once you go to bed, you will sleep until the next morning."
    # )
    EMMA_MORNINGS_PROMPT = (
        "Date: 2023-09-01, Monday. It's 6am in the morning, you are Emma. "
        "You are a doctor just waking up in your room. "
        "You need to plan your morning routine and leave your home before 7:30am."
    )

    EMMA_EVENINGS_PROMPT = (
        "Date: 2023-09-01, Monday. It's 5pm in the evening, you are Emma. "
        "You are a doctor just coming back home from work. "
        "You need to plan your evening routine and here is your lifestyle: {}. "
        "Once you go to bed, you will sleep until the next morning."
    )

    EMMA_NEXT_DAY_MORNINGS_PROMPT = (
        "Date: {date}. It's 6am in the morning, you are Emma. "
        "You are a doctor just waking up in your room. "
        "Yesterday, you accomplished the following plans: {previous_plan}. "
        "You need to plan your morning routine and leave your home before 7:30am. "
        "Once you leave home, you will start your work at the hospital."
        "If today is a weekend, you don't need to go to work. Instead, you will go out and enjoy holiday time with your family."
    )

    EMMA_NEXT_DAY_EVENINGS_PROMPT = (
        "Date: {date}. It's 5pm in the evening, you are Emma. "
        "You are a doctor just coming back home from work. "
        "Yesterday, you accomplished the following plans: {previous_plan}. "
        "You need to plan your evening routine and here is your lifestyle: {life_style}. "
        "Once you go to bed, you will sleep until the next morning."
        "If today is a weekend, you will have spent the day enjoying time with your family instead of working."
    )

    # JASON_MORNINGS_PROMPT = (
    #     "It's 6:30am in the morning, you are Jason"
    #     "You are a lawyer just waking up in your room."
    #     "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan."
    #     "You need to plan your morning routine and leave your home before 8:00am."
    # )

    # JASON_EVENINGS_PROMPT = (
    #     "It's 7pm in the evening, you are Jason"
    #     "You are a lawer just coming back home from court."
    #     "Here is your fmaily's plan: {}, please ensure your plan is not conflicting with your family's plan."
    #     "You need to plan your evening routine and here is your lifestyle: {}"
    #     "You need to start sleeping on time and wake up on time."
    # )
    # JASON_EVENINGS_PROMPT = (
    #     "It's 7pm in the evening, you are Jason. "
    #     "You are a lawyer just coming back home from court. "
    #     "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan. "
    #     "You need to plan your evening routine and here is your lifestyle: {}. "
    #     "You need to start sleeping on time and wake up on time. "
    #     "Once you go to bed, you will sleep until the next morning."
    # )
    #
    # JASON_NEXT_DAY_MORNINGS_PROMPT = (
    #     "It's 6:30am in the morning, you are Jason. "
    #     "You are a lawyer just waking up in your room. "
    #     "Yesterday, you accomplished the following plans: {}. "
    #     "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan. "
    #     "You need to plan your morning routine and leave your home before 8:00am. "
    #     "Once you leave home, you will head to the court for your cases."
    # )
    #
    # JASON_NEXT_DAY_EVENINGS_PROMPT = (
    #     "It's 7pm in the evening, you are Jason. "
    #     "You are a lawyer just coming back home from court. "
    #     "Yesterday, you accomplished the following plans: {}. "
    #     "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan. "
    #     "You need to plan your evening routine and here is your lifestyle: {}. "
    #     "You need to start sleeping on time and wake up on time. "
    #     "Once you go to bed, you will sleep until the next morning."
    # )
    JASON_MORNINGS_PROMPT = (
        "Date: 2023-09-01, Monday. It's 6:30am in the morning, you are Jason. "
        "You are a lawyer just waking up in your room. "
        "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan. "
        "You need to plan your morning routine and leave your home before 8:00am."
    )

    JASON_EVENINGS_PROMPT = (
        "Date: 2023-09-01, Monday. It's 7pm in the evening, you are Jason. "
        "You are a lawyer just coming back home from court. "
        "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan. "
        "You need to plan your evening routine and here is your lifestyle: {}. "
        "You need to start sleeping on time and wake up on time. "
        "Once you go to bed, you will sleep until the next morning."
    )

    JASON_NEXT_DAY_MORNINGS_PROMPT = (
        "Date: {date}. It's 6:30am in the morning, you are Jason. "
        "You are a lawyer just waking up in your room. "
        "Yesterday, you accomplished the following plans: {previous_plan}. "
        "You need to plan your morning routine and leave your home before 8:00am. "
        "Once you leave home, you will head to the court for your cases."
        "If today is a weekend, you don't need to go to work. Instead, you will go out and enjoy holiday time with your family."
    )

    JASON_NEXT_DAY_EVENINGS_PROMPT = (
        "Date: {date}. It's 7pm in the evening, you are Jason. "
        "You are a lawyer just coming back home from court. "
        "Yesterday, you accomplished the following plans: {previous_plan}. "
        "You need to plan your evening routine and here is your lifestyle: {life_style}. "
        "You need to start sleeping on time and wake up on time. "
        "Once you go to bed, you will sleep until the next morning."
        "If today is a weekend, you will have spent the day enjoying time with your family instead of working."
    )
    
    # TOMMIE_MORNINGS_PROMPT = (
    #     "It's 7am in the morning, you are Tommie"
    #     "You are a computer science student just waking up in your room."
    #     "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan."
    #     "You need to plan your morning routine and leave your home before 8:30am."
    # )

    # TOMMIE_EVENINGS_PROMPT = (
    #     "It's 6pm in the evening, you are Tommie"
    #     "You are a computer science student just coming back home from university."
    #     "Here is your fmaily's plan: {}, please ensure your plan is not conflicting with your family's plan."
    #     "You need to plan your evening routine and here is your lifestyle: {}"
    #     "You need to start sleeping on time and wake up on time."
    # )
    # TOMMIE_EVENINGS_PROMPT = (
    #     "It's 6pm in the evening, you are Tommie. "
    #     "You are a computer science student just coming back home from university. "
    #     "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan. "
    #     "You need to plan your evening routine from 6pm till you wake up the next morning, and here is your lifestyle: {}"
    #     "you go to sleep at midnight (12am) and wake up at 7am. "
    #     "You need to start sleeping on time and wake up on time."
    # )
    #
    # TOMMIE_NEXT_DAY_MORNINGS_PROMPT = (
    #     "It's 7am in the morning, you are Tommie. "
    #     "You are a computer science student just waking up in your room. "
    #     "Yesterday, you accomplished the following plans: {}. "
    #     "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan. "
    #     "You need to plan your morning routine and leave your home before 8:30am. "
    #     "Once you leave home, you will head to the university for your classes."
    # )
    #
    # TOMMIE_NEXT_DAY_EVENINGS_PROMPT = (
    #     "It's 6pm in the evening, you are Tommie. "
    #     "You are a computer science student just coming back home from university. "
    #     "Yesterday, you accomplished the following plans: {}. "
    #     "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan. "
    #     "You need to plan your evening routine from 6pm till you wake up the next morning, and here is your lifestyle: {}. "
    #     "You go to sleep at midnight (12am) and wake up at 7am. "
    #     "You need to start sleeping on time and wake up on time."
    # )
    TOMMIE_MORNINGS_PROMPT = (
        "Date: 2023-09-01, Monday. It's 7am in the morning, you are Tommie. "
        "You are a computer science student just waking up in your room. "
        "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan. "
        "You need to plan your morning routine and leave your home before 8:30am."
    )

    TOMMIE_EVENINGS_PROMPT = (
        "Date: 2023-09-01, Monday. It's 6pm in the evening, you are Tommie. "
        "You are a computer science student just coming back home from university. "
        "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan. "
        "You need to plan your evening routine from 6pm till you wake up the next morning, and here is your lifestyle: {}. "
        "You need to start sleeping on time and wake up on time."
    )

    TOMMIE_NEXT_DAY_MORNINGS_PROMPT = (
        "Date: {date}. It's 7am in the morning, you are Tommie. "
        "You are a computer science student just waking up in your room. "
        "Yesterday, you accomplished the following plans: {previous_plan}. "
        "You need to plan your morning routine and leave your home before 8:30am. "
        "Once you leave home, you will head to the university for your classes."
        "If today is a weekend, you don't need to go to university. Instead, you will go out and enjoy holiday time with your family."
    )

    TOMMIE_NEXT_DAY_EVENINGS_PROMPT = (
        "Date: {date}. It's 6pm in the evening, you are Tommie. "
        "You are a computer science student just coming back home from university. "
        "Yesterday, you accomplished the following plans: {previous_plan}. "
        "You need to plan your evening routine from 6pm till you wake up the next morning, and here is your lifestyle: {life_style}. "
        "You need to start sleeping on time and wake up on time."
        "If today is a weekend, you will have spent the day enjoying time with your family instead of attending classes."
    )

    AMBER_MORNINGS_PROMPT = (
        "Date: 2023-09-01, Monday. It's 7am in the morning, you are Amber"
        "You are a high school student just waking up in your room."
        "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan."
        "You need to plan your morning routine and leave your home before 9:00am."
    )

    AMBER_EVENINGS_PROMPT = (
        "Date: 2023-09-01, Monday. It's 4pm in the afternoon, you are Amber"
        "You are a high school student just coming back home from school."
        "Here is your family's plan: {}, please ensure your plan is not conflicting with your family's plan."
        "You need to plan your evening routine and here is your lifestyle: {}"
        "You need to start sleeping on time and wake up on time."
    )

    AMBER_NEXT_DAY_MORNINGS_PROMPT = (
        "Date: {date}. It's 7am in the morning, you are Amber. "
        "You are a high school student just waking up in your room. "
        "Yesterday, you accomplished the following plans: {previous_plan}. "
        "You need to plan your morning routine and leave your home before 9:00am. "
        "Once you leave home, you will head to the school for your classes."
        "If today is a weekend, you don't need to go to school. Instead, you will go out and enjoy holiday time with your family."
    )

    AMBER_NEXT_DAY_EVENINGS_PROMPT = (
        "Date: {date}. It's 4pm in the afternoon, you are Amber. "
        "You are a high school student just coming back home from school. "
        "Yesterday, you accomplished the following plans: {previous_plan}. "
        "You need to plan your evening routine and here is your lifestyle: {life_style}. "
        "You need to start sleeping on time and wake up on time."
        "If today is a weekend, you will have spent the day enjoying time with your family instead of attending classes."
    )


    # Give a detailed prompt to the LLMS
    @staticmethod
    def get_env_objects():

        template = """What are the environmental information in the following observation? 
                    You can check your environment data by using the tool {getEnvData}. 
                    Your feedback should be in the EXACT format below.
                    {format_instructions}"""
        
        # Reponse structured as a json object. This is basically a fancy prompt template
        response_schemas = [
                    ResponseSchema(name="env_information", description="This the environmental information that saved in a dictionary."),
        ]

        # Parse the output in a json object
        #output_parser = StructuredOutputParser.from_response_schemas(response_schemas)
        output_parser = JsonOutputParser()
        format_instructions = output_parser.get_format_instructions()

        return template, output_parser, format_instructions
    
    def change_env_status():
        # only homebot
        # template = """Please think you are a human in {room}. Your name is {name}.
        #             It's now {time} and you are going to do {task}.
        #             Please control the device to meet your {preference}. 
        #             You can check your environment data by using the tool {getEnvData}.
        #             The all SMART devices {smart_devices}.
        #             You can present your feelings or requests to the home bot in natural language by using the tool {controlHomeBot}.
        #             When using {controlHomeBot}, ensure you using the following FORMAT: dict("input": "your requirements", "room": "room name", "name": "your name"), and second input is "home_bot", 
        #             Your feedback should be in the format below.
        #             If you think the environment is comfortable enough, no need to change the environment.
        #             ====================
        #             {format_instructions}"""
        

        # template = """Please think you are a human in {room}. Your name is {name}.
        #             It's now {time} and you are going to do {task}.
        #             Please control the device to meet your {preference}. 
        #             You can check your environment data by using the tool {getEnvData}.
        #             You can check what you can do with the SMART device by using tool {getDeviceController}.
        #             The SMART devices list: {smart_devices}.
        #             You also can control the all devices by using the tool {controlDevice}. 
        #             When using {controlDevice}, if you are trying to control SMART device, ensure you know what the SMART device can do through tool {getDeviceController}.
        #             Your feedback should be in the format below.
        #             If you think the environment is comfortable enough, no need to change the environment.
        #             ====================
        #             {format_instructions}"""
        
        # both homebot and devices
        # template = """Please think you are a human in {room}. Your name is {name}.
        #             It's now {time} and you are going to do {task}.
        #             Please control the device to meet your {preference}.
        #             You can check your environment data by using the tool {getEnvData}.
        #             You can check what you can do with the SMART device by using tool {getDeviceController}.
        #             The all SMART devices {smart_devices}.
        #             You can present your feelings or requests to the home bot in natural language by using the tool {controlHomeBot}.
        #             You also can control the all devices by using the tool {controlDevice}.
        #             When using {controlHomeBot}, ensure you using the following FORMAT: dict("input": "your requirements", "room": "room name", "name": "your name"),
        #             When using {controlDevice}, if you are trying to control SMART device, ensure you know what the SMART device can do through tool {getDeviceController}.
        #             When using {controlDevice}, ensure you are using the following FORMAT: dict("room": room_name, "device": dict("action1": choice, "action2": choice, ...)).
        #             Your feedback should be in the format below.
        #             If you think the environment is comfortable enough, no need to change the environment.
        #             ====================
        #             {format_instructions}"""
        template = """Please think you are a human in {room}. Your name is {name}.
                    It's now {time} and you are going to do {task}.
                    Please control the device to meet your {preference}. 
                    You can check your environment data by using the tool {getEnvData}.
                    You can check what you can do with the SMART device by using tool {getDeviceController}.
                    The all SMART devices {smart_devices}.
                    You can present your feelings or requests to the home bot in natural language by using the tool {controlHomeBot}.
                    You also can control the all devices by using the tool {controlDevice}. 
                    When using {controlHomeBot}, ensure you using the following FORMAT: dict("input": "your requirements", "room": "room name", "name": "your name"), 
                    When using {controlDevice}, if you are trying to control SMART device, ensure you know what the SMART device can do through tool {getDeviceController}.
                    When using {controlDevice}, ensure you are using the following FORMAT: dict("room": room_name, "device": dict("action1": choice, "action2": choice, ...)).
                    If you are adjusting the brightness, please enclose the adjustment number in single quotes.
                    Your feedback should be in the format below.
                    If you think the environment is comfortable enough, no need to change the environment.
                    ====================
                    {format_instructions}"""

        # Reponse structured as a json object. This is basically a fancy prompt template
        response_schemas = [
                    ResponseSchema(name="curr_env", description="This the current environmental data after update."),
                    ResponseSchema(name="change_reason", description="This the reason why you update (or not update) the environment."),
        ]

        # Parse the output in a json object
        #output_parser = StructuredOutputParser.from_response_schemas(response_schemas)
        output_parser = JsonOutputParser()
        format_instructions = output_parser.get_format_instructions()

        return template, output_parser, format_instructions
    
    def homebot_change_env():
        template = """Please think you are a smart house keeper.
                    Your job is adjusting the smart devices in the house to let everyone feel comfortable and save energy if possible.
                    It's now {time} and the status of the family members is {family_status}.
                    Please control the device to meet family member's preference: {all_preference}. 
                    You can check the environment data by using the tool {getFloorData}. 
                    The all SMART devices: {smart_devices}.
                    You can check what you can do with the SMART device by using tool {getDeviceController}, you only need to check the same device once for different rooms.
                    You can only control the SMART device in each room by using the tool {controlDeviceMulti}.
                    When using {controlDeviceMulti}, ensure you know what the SMART device can do through tool {getDeviceController}.
                    When using {controlDeviceMulti}, you can control multiple SMART devices in multiple rooms at once, ensure you are using the following FORMAT: [dict("room": room_name, "device1": dict("action1": choice, "action2": choice, ...)]). 
                    If you are adjusting the brightness, please enclose the adjustment number in single quotes.
                    Your feedback should be in the format below.
                    If you think the environment is comfortable enough, no need to change the environment.
                    ====================
                    {format_instructions}"""
        
        # Reponse structured as a json object. This is basically a fancy prompt template
        response_schemas = [
                    ResponseSchema(name="curr_env", description="This the current environmental data after update."),
                    ResponseSchema(name="change_reason", description="This the reason why you update (or not update) the environment."),
        ]

        # Parse the output in a json object
        #output_parser = StructuredOutputParser.from_response_schemas(response_schemas)
        output_parser = JsonOutputParser()
        format_instructions = output_parser.get_format_instructions()

        return template, output_parser, format_instructions

    def human_asked_homebot_change_env():
        template = """Please think you are a smart house keeper.
                    Your job is adjusting the smart devices in the house to let everyone feel comfortable and save energy if possible.
                    Please control the device to meet {human_name}'s requirements: {human_requirements}. 
                    You can check the environment data by using the tool {getFloorData}. 
                    You can check what you can do with the device by using tool {getDeviceController}.
                    You can control the device in each room by using the tool {controlDeviceMulti}.
                    When using {controlDeviceMulti}, ensure you know what the device can do through tool {getDeviceController}.
                    When using {controlDeviceMulti}, you can control multiple devices in multiple rooms at once, ensure you are using the following FORMAT: [dict("room": room_name, "device1": dict("action1": choice, "action2": choice, ...)]). 
                    Your feedback should be in the FORMAT below:
                    ====================
                    {format_instructions}"""

        # Reponse structured as a json object. This is basically a fancy prompt template
        response_schemas = [
                    ResponseSchema(name="status", description="If meet the human requirements, set 'succeed', otherwise set 'fail'."),
                    ResponseSchema(name="reason", description="Describe what you did (when succeed) or why fail (when fail)."),
        ]

        # Parse the output in a json object
        #output_parser = StructuredOutputParser.from_response_schemas(response_schemas)
        output_parser = JsonOutputParser()
        format_instructions = output_parser.get_format_instructions()

        return template, output_parser, format_instructions