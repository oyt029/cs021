import os
import json
import ast
import re
from langchain.agents import Tool
from typing import Optional

from device_simulation.device_factory import CustomDeviceFactory

device_factory = CustomDeviceFactory("device_simulation/devices.json")
SUPPORT_DEVICES = list(device_factory.show_devices().keys())
SUPPORT_MODELS = [x.split(":")[1] for x in device_factory.show_devices().keys()]

def new_control_logic(agent_query: dict, env_data: dict):
    for agent_key, agent_value in agent_query.items():
        if agent_key == "room":
            continue
        try:
            device_name = f"{agent_query['room']}:{agent_key}"
            try:
                latest_device_status = device_factory.check_device_status(device_name)
            except:
                latest_device_status = env_data[agent_key]
        except:
            return 'Format Error. This should have FORMAT as following: dict("room": room_name, "device_name1": dict("action1": choice, ...)).'
        
        if agent_key in env_data.keys() and agent_key not in SUPPORT_MODELS:
            env_data[agent_key] = agent_value
            
        elif agent_key in env_data.keys():
            for action, choice in agent_value.items():
                if "power" in latest_device_status and latest_device_status["power"] == "off" and action != "power":
                    return "You can't do anything else until you set the 'power' of the device to 'on'."
                
                if action == "target_temperature" or action == "target_humidity":
                    if not isinstance(choice, int):
                        if choice[-1].lower() == 'c' or choice[-1].lower() == '%':
                            try:
                                choice = int(choice[:-1])
                            except:
                                return f"For {agent_key}, the choice format of action {action} is wrong."
                try:
                    latest_device_status = device_factory.execute(device_name, action, choice)
                except:
                    return "Wrong Action or wrong choice, please try to check actions again."
            
            # check if the temperature or humidity changed
            if "target_temperature" in latest_device_status:
                env_data['temperature'] = f"{latest_device_status['target_temperature']}C"
                latest_device_status['target_temperature'] = f"{latest_device_status['target_temperature']}C"
            
            if "target_humidity" in latest_device_status:
                env_data['humidity'] = f"{latest_device_status['target_humidity']}%"
                latest_device_status['target_humidity'] = f"{latest_device_status['target_humidity']}%"
            
            if "power" in latest_device_status:
                if latest_device_status["power"] == "off":
                    env_data[agent_key] = {"power": "off"}
                else:
                    # update device to env data
                    env_data[agent_key] = latest_device_status
            else:
                # update device to env data
                env_data[agent_key] = latest_device_status

        else:
            return f"{agent_key} doesn't exists."

    return env_data
                


# ======== Define function to control the device ======== #
#def control_device(agent_query:str):

#    # Convert the agent query to a dictionary
#    try:
#        agent_query = ast.literal_eval(agent_query)
#    except:
#        if 'dict' in agent_query:
#            return "FORMAT ERROR: You need to use '{' and '}' to instead of dict()."
#        else:
#            return "FORMAT ERROR: Please try again."

def control_device(agent_query: str):
        # 替换agent_query中的'dict()'为'{}'

    if 'dict(' in agent_query:
        agent_query = agent_query.replace('dict(', '{').replace(')', '}')

        # 将agent_query转换为字典
    try:
        agent_query = ast.literal_eval(agent_query)
    except:
        return "FORMAT ERROR: Please try again."

    current_dir = os.getcwd()

    if 'room' in agent_query.keys():

        room = agent_query['room']
        env_data_path = os.path.join(current_dir, 'data', 'envData', f'{room}_data.json')

        try:
            with open(env_data_path, 'r') as f:
                env_data = json.load(f)
        except:
            return "Please follow the dict format to include the room to control the device. (e.g. {'room': 'bedroom'})"

        for key in agent_query.keys():
            if key not in env_data:
                return f"There are no {key} in {env_data['room']}."

        # Update the environment data
        updated_env_data = new_control_logic(agent_query, env_data)
        
        # Check the return type
        if not isinstance(updated_env_data, dict):
            return updated_env_data
        
        with open(env_data_path, 'w') as f:
            json.dump(updated_env_data, f, indent=4)

        return updated_env_data
    else:
        return "Please follow the dict fomrat to include the room to control the device. (e.g. {'room': 'bedroom'})"

def control_device_multi(agent_queries:str):
#    try:
#        agent_queries = ast.literal_eval(agent_queries)
#    except:
#        if 'dict' in agent_queries:
#            return "FORMAT ERROR: You need to use '{' and '}' to instead of dict()."
#        else:
#            return "FORMAT ERROR: Please try again."
    #if 'dict(' in agent_queries:
    #    agent_queries = agent_queries.replace('dict(', '{').replace(')', '}')


    # # 将agent_query转换为字典
    # try:
    #
    #     agent_queries = ast.literal_eval(agent_queries)
    # except:
    #     return "FORMAT ERROR: Please try again."

    if 'dict(' in agent_queries:
        agent_queries = agent_queries.replace('dict(', '{').replace(')', '}')
    try:
        # 将 agent_queries 从字符串解析为 Python 对象
        agent_queries = ast.literal_eval(agent_queries)
    except Exception as e:
        if 'dict' in agent_queries:
            return "FORMAT ERROR: You need to use '{' and '}' to instead of dict()."
        else:
            return f"FORMAT ERROR: Please try again. Error: {str(e)}"

    # Ensure agent_queries is a list, even if only one dict is passed
    if not isinstance(agent_queries, list):
        agent_queries = [agent_queries]

    results = []

    current_dir = os.getcwd()

    for agent_query in agent_queries:

        if agent_query and 'room' in agent_query.keys():
            room = agent_query['room']
            env_data_path = os.path.join(current_dir, 'data', 'envData', f'{room}_data.json')

            try:
                with open(env_data_path, 'r') as f:
                    env_data = json.load(f)
            except:
                return "Please follow the dict format to include the room to control the device. (e.g. {'room': 'bedroom'})"

            if "devices" in agent_query:
                return "Don't need to add devices into 'devices' keyword. This should have FORMAT as following: dict('room': room_name, 'device_name1': dict('action1': choice, ...))"

            for key in agent_query.keys():
                if key not in env_data:
                    return f"There are no {key} in {env_data['room']}."

            # Update the environment data
            updated_env_data = new_control_logic(agent_query, env_data)

            # Check the return type
            if not isinstance(updated_env_data, dict):
                return updated_env_data

            with open(env_data_path, 'w') as f:
                json.dump(updated_env_data, f, indent=4)
        else:
            return "Please follow the dict format to include the room to control the device. (e.g. {'room': 'bedroom'})"

    for json_file in os.listdir(os.path.join(current_dir, 'data', 'envData')):
        if json_file.endswith(".json"):
            with open(os.path.join(current_dir, 'data', 'envData', json_file), 'r') as f:
                env_data = json.load(f)
            results.append(env_data)
    return results


# def control_device_multi(agent_queries: str):
#     try:
#         # 将 agent_queries 从字符串解析为 Python 对象
#         agent_queries = ast.literal_eval(agent_queries)
#         if 'dict(' in agent_queries:
#             agent_queries = agent_queries.replace('dict(', '{').replace(')', '}')
#     except Exception as e:
#         if 'dict' in agent_queries:
#             return "FORMAT ERROR: You need to use '{' and '}' to instead of dict()."
#         else:
#             return f"FORMAT ERROR: Please try again. Error: {str(e)}"
#
#     # 确保 agent_queries 是一个列表，即使仅传递了一个字典
#     if not isinstance(agent_queries, list):
#         agent_queries = [agent_queries]
#
#     results = []
#
#     current_dir = os.getcwd()
#
#     for agent_query in agent_queries:
#         if agent_query and 'room' in agent_query.keys():
#             room = agent_query['room']
#             env_data_path = os.path.join(current_dir, 'data', 'envData', f'{room}_data.json')
#
#             try:
#                 with open(env_data_path, 'r') as f:
#                     env_data = json.load(f)
#             except Exception as e:
#                 return f"Error loading environment data for room '{room}': {str(e)}"
#
#             if "devices" in agent_query:
#                 return "FORMAT ERROR: Don't need to add devices into 'devices' keyword. This should have FORMAT as following: {'room': room_name, 'device_name1': {'action1': choice, ...}}"
#
#             for device, commands in agent_query.items():
#                 if device == 'room':
#                     continue
#
#                 if device not in SUPPORT_DEVICES:
#                     return f"Error: Device '{device}' is not supported in room '{room}'."
#
#                 for command, value in commands.items():
#                     if command not in SUPPORT_MODELS.get(device, []):
#                         return f"Error: Action '{command}' is not supported for device '{device}' in room '{room}'."
#
#             # 更新环境数据
#             updated_env_data = new_control_logic(agent_query, env_data)
#
#             # 检查返回类型是否为字典
#             if not isinstance(updated_env_data, dict):
#                 return updated_env_data
#
#             try:
#                 with open(env_data_path, 'w') as f:
#                     json.dump(updated_env_data, f, indent=4)
#             except Exception as e:
#                 return f"Error saving updated environment data for room '{room}': {str(e)}"
#         else:
#             return "FORMAT ERROR: Please follow the dict format to include the room to control the device. (e.g. {'room': 'bedroom'})"
#
#     # 读取所有环境数据文件并返回结果
#     for json_file in os.listdir(os.path.join(current_dir, 'data', 'envData')):
#         if json_file.endswith(".json"):
#             with open(os.path.join(current_dir, 'data', 'envData', json_file), 'r') as f:
#                 env_data = json.load(f)
#             results.append(env_data)
#
#     return results

# ======== Define function to get single room information from envData ======== #
def get_env_data(room: str):
    current_dir = os.getcwd()
    room = room.strip().strip('"')
    if room:
        env_data_path = os.path.join(current_dir, 'data', 'envData', f'{room.lower()}_data.json')
        try:
            with open(env_data_path, 'r') as f:
                env_data = json.load(f)
        except:
            return "Please use the right room format. (e.g. {'room': 'main_bedroom'})"
        
        return env_data
    else:
        return "Please choose the room to get the enviroment data."

# ======== Define function to get all the information from envData ======== #
def get_floor_data(agent_query: Optional[str] = None):

    env_data_path = os.path.join(os.getcwd(), 'data', 'envData')

    room_list = ["bedroom", "main_bedroom", "bathroom", "kitchen", "living_room", "front_door"]
    floor_data = []
    for room in room_list:
        with open(os.path.join(env_data_path, f"{room}_data" + ".json"), 'r') as f:
            room_data = json.load(f)
        
        floor_data.append(room_data)

    return floor_data

# ======== Define function to get the device actions ======== #
#def get_device_controller(agent_query: str):
#    if agent_query not in SUPPORT_DEVICES:
#        return f"This device does not support intelligent control. If you are the smart house keeper, you cannot control this device. If you are human, control the device directly according to the format in env_data."
#    return device_factory.check_device_actions(agent_query)

def get_device_controller(agent_query: str):
    # 清理字符串前后的空白字符和换行符
    agent_query = agent_query.strip().strip('"')

    # 使用正则表达式去除多余的符号
    #agent_query = re.sub(r'[^a-zA-Z0-9:_-]', '', agent_query)
    # 如果字符串是由房间名和设备名组合而成，例如 "main_bedroom:humidifier"
    if ':' in agent_query:
        room_device = agent_query.split(':')
        if len(room_device) == 2:
            agent_query = f"{room_device[0]}:{room_device[1]}"
        else:
            return "Invalid format for agent_query. Expected 'room:device'."

    if agent_query not in SUPPORT_DEVICES:
        return f"This device does not support intelligent control. If you are the smart house keeper, you cannot control this device. If you are human, control the device directly according to the format in env_data."
    return device_factory.check_device_actions(agent_query)

    


controlDevice = Tool(
                name='Device Control',
                description=('A tool to control the device.' 
                             'The input is a dictionary with the key being the device name and the value being the dictionary of device actions.'
                             'This should have FORMAT as following: dict("room": room_name, "device1": dict("action1": choice, ...), ...).'), 
                func=control_device,)

getEnvData = Tool(
                name='Get Environment Data',
                description=('A tool to get the current enviroment data.'
                             'The input should be only the room name.'
                             'Useful for when you need to know the enviromental data.'), 
                func=get_env_data,)

getFloorData = Tool(
                name='Get Floor Data',
                description=('A tool to get the current enviroment data in the whole room.'
                             'No input reuqired, just call this function.'
                             'Useful for when you need to know the enviromental data.'), 
                func=get_floor_data,)

controlDeviceMulti = Tool(
                name='Device Control in Multiple Rooms',
                description=('A tool to control device in multiple rooms.' 
                             'The input is a list of dictionary. Each dictionary refers to a room. The dictionary with the key being the device name and the value being the dictionary of device actions.'
                             'This should have FORMAT as following: list(dict("room": room_name, "device1": dict("action1": choice, ...), ...), ...).'), 
                func=control_device_multi,)

getDeviceController = Tool(
    name='Get the Device Controller',
    description=('A tool that let you get the actions you can do with the device.'
                 'The input is a string consisting of room_name and device_name. The FORMAT is "room_name:device_name", such as "main_bedroom:lamp".'
                 'Useful for when you need to know what you can do with the device.'),
    func=get_device_controller,)
