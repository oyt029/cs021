## This file contains helper functions for the main script
## Author: Zhihao Zhang (zhihao.zhang1@sydney.edu.au)
## Date: 2023-08-17
import re
import os
import json
from langchain_experimental.plan_and_execute.schema import (
    Plan,
    PlanOutputParser,
    Step,
)

from datetime import datetime, timedelta

clear_flag = {}
# ======== Define the planning output parser ======== #
class PlanningOutputParser(PlanOutputParser):
    """Planning output parser."""

    def parse(self, text: str) -> Plan:
        steps = [Step(value=v) for v in re.split("\n\s*\d+\. ", text)[1:]]
        return Plan(steps=steps)

# ======== Load the agent initial information ======== #
def load_agent_info(info_path: str) -> dict:
    with open(info_path, 'r') as f:
        agent_info = json.load(f)
    return agent_info

# ======== Define the plan to list function ======== #
def plan_to_list(plan_string:str) -> list:
    # # Split the string by lines
    # lines = plan_string.split("\n")
    
    # # Filter out any lines that don't match the expected format (e.g. "Plan:", "<END_OF_PLAN>")
    # lines = [line.split(".")[1].strip() for line in lines if re.match(r'\d+\.', line)]
    lines = [line.strip() for line in plan_string.split("\n") if line.strip() and not line.strip().startswith("<END_OF_PLAN>")]
    return lines

# ======== Define the compute duration function ======== #
# def compute_duration(start_time, end_time):
#     # Extract hour and minute from the time strings
#     start_hour, start_minute = map(int, start_time.split(":"))
#     end_hour, end_minute = map(int, end_time.split(":"))
#
#     # Adjusting for times past midnight
#     if end_hour < start_hour or (end_hour == start_hour and end_minute < start_minute):
#         end_hour += 24
#
#     # Calculate duration in minutes
#     duration = (end_hour - start_hour) * 60 + (end_minute - start_minute)
#     return duration
def compute_duration(start_time, end_time):
    """
    Compute the duration between start_time and end_time in minutes.
    """
    start_datetime = datetime.strptime(start_time, "%H:%M")
    end_datetime = datetime.strptime(end_time, "%H:%M")

    # Adjusting for times past midnight
    if end_datetime < start_datetime:
        end_datetime += timedelta(days=1)

    duration = (end_datetime - start_datetime).total_seconds() // 60
    return int(duration)

# ======== Define the plan to dict function ======== #
def plan_to_act(plan_string:str) -> dict:

    lines = [line.strip() for line in plan_string.split("\n") if line.strip() and not line.strip().startswith("<END_OF_PLAN>")]

    act_plan = []
    for line in lines:
        # Extract the time, action and place using regex
        #match = re.match(r"\d+\.\s*\[\s*([\d:]+)\s*-\s*([\d:]+)\s*\]\s*([^-]+)\s*-\s*(.+)", line)
        match = re.match(r"\d+\.\s*\[\s*([\d-]+\s+[\d:]+)\s*-\s*([\d:]+)\s*\]\s*([^-]+)\s*-\s*(.+)", line)
        # if match:
        #     start_time, end_time, action, place = match.groups()
        #
        #     # Compute the duration
        #     duration = compute_duration(start_time, end_time)
        #
        #     act_plan.append({
        #         "act_place": place.lower(),
        #         "start_time": start_time,
        #         "end_time": end_time,
        #         "action": action,
        #         "duration": duration
        #     })
        if match:
            start_datetime, end_time, action, place = match.groups()
            start_date, start_time = start_datetime.split(' ')

            # Compute the duration
            duration = compute_duration(start_time, end_time)

            act_plan.append({
                "act_place": place.lower(),
                "start_date": start_date,
                "start_time": start_time,
                "end_time": end_time,
                "action": action,
                "duration": duration
            })

    return act_plan, lines

# ======== Define function to save plan into agent info ======== #
# def save_plans(plan_string:str, agent_info_path:str):
#     agent_plan = {}
#     # Test the function
#
#     agent_info = load_agent_info(agent_info_path)
#     curr_plan, plan_list = plan_to_act(plan_string)
#     # for item in plan_list:
#     #     # print(plan_to_act(item))
#     #     if agent_info['act_plan'] != []:
#     #         curr_plan = agent_info['act_plan']
#
#     #     curr_plan.append(plan_to_act(item))
#
#     agent_info['act_plan'] = curr_plan
#     agent_plan['name'] = agent_info['first_name']
#
#     # using enumerate() to iterate for index and values
#     for itm in curr_plan:
#         itm.update({'name': agent_info['first_name']})
#
#     agent_plan['plan'] = curr_plan
#     # print(agent_info)
#     with open(agent_info_path, 'w') as f:
#         json.dump(agent_info, f, indent=4)
#         print("Plan saved into agent file.")
#
#     return plan_list, agent_plan, agent_info
# def save_plans(plan_string: str, agent_info_path: str):
#     agent_plan = {}
#
#     # 获取代理名称
#     agent_name = agent_info_path.split('/')[-1].split('.')[0]
#
#     # 如果代理不在clear_flag字典中，或其标志为False，则执行清空操作
#     if agent_name not in clear_flag or not clear_flag[agent_name]:
#         agent_info = load_agent_info(agent_info_path)
#         agent_info['act_plan'] = []  # 清空 act_plan
#         clear_flag[agent_name] = True  # 设置标志为True
#         with open(agent_info_path, 'w') as f:
#             json.dump(agent_info, f, indent=4)  # 保存清空后的文件
#             print(f"Cleared plan for agent {agent_name}.")
#     else:
#         # 载入现有的代理信息
#         agent_info = load_agent_info(agent_info_path)
#
#     # 解析新的计划
#     curr_plan, plan_list = plan_to_act(plan_string)
#
#     # 如果已有计划，则将新的计划追加到现有计划中
#     if 'act_plan' in agent_info and agent_info['act_plan']:
#         existing_plans = agent_info['act_plan']
#     else:
#         existing_plans = []
#
#     # 追加新的计划
#     existing_plans.extend(curr_plan)
#
#     # 更新代理信息
#     agent_info['act_plan'] = existing_plans
#     agent_plan['name'] = agent_info['first_name']
#
#     # 使用 enumerate() 来迭代索引和值
#     for itm in curr_plan:
#         itm.update({'name': agent_info['first_name']})
#
#     agent_plan['plan'] = existing_plans
#
#     # 保存到文件中
#     with open(agent_info_path, 'w') as f:
#         json.dump(agent_info, f, indent=4)
#         print("Plan saved into agent file.")
#
#     return plan_list, agent_plan, agent_info
def save_plans(plan_string: str, agent_info_path: str, day: str):
    agent_plan = {}

    # 获取代理名称
    agent_name = agent_info_path.split('/')[-1].split('.')[0]

    # 如果代理不在clear_flag字典中，或其标志为False，则执行清空操作
    if agent_name not in clear_flag or not clear_flag[agent_name]:
        agent_info_list = load_agent_info(agent_info_path)
        for day_info in agent_info_list:
            day_info['act_plan'] = []  # 清空 act_plan
        clear_flag[agent_name] = True  # 设置标志为True
        with open(agent_info_path, 'w') as f:
            json.dump(agent_info_list, f, indent=4)  # 保存清空后的文件
            print(f"Cleared plan for agent {agent_name}.")
    else:
        # 载入现有的代理信息
        agent_info_list = load_agent_info(agent_info_path)

    # 解析新的计划
    curr_plan, plan_list = plan_to_act(plan_string)

    # 找到对应天的计划并更新 'act_plan'
    for day_info in agent_info_list:
        if day_info['daily_plan'] == day:
            existing_plans = day_info.get('act_plan', [])
            existing_plans.extend(curr_plan)
            day_info['act_plan'] = existing_plans
            agent_plan['name'] = day_info.get('first_name', agent_name)
            for itm in curr_plan:
                itm.update({'name': agent_plan['name']})
            agent_plan['plan'] = day_info['act_plan']

    # 保存到文件中
    with open(agent_info_path, 'w') as f:
        json.dump(agent_info_list, f, indent=4)
        print(f"Plan saved into {day} for agent {agent_name}.")

    return plan_list, agent_plan, agent_info_list


    # # 如果已有计划，则将新的计划追加到现有计划中
    # if 'act_plan' in agent_info and agent_info['act_plan']:
    #     existing_plans = agent_info['act_plan']
    # else:
    #     existing_plans = []
    #
    # # 追加新的计划
    # existing_plans.extend(curr_plan)
    #
    # # 更新代理信息相关字段
    # agent_info['act_plan'] = existing_plans
    # agent_info['daily_plan'] = day
    # agent_plan['name'] = agent_info['first_name']
    #
    # # 使用 enumerate() 来迭代索引和值
    # for itm in curr_plan:
    #     itm.update({'name': agent_info['first_name']})
    #
    # agent_plan['plan'] = existing_plans
    #
    # # 保存到文件中
    # with open(agent_info_path, 'w') as f:
    #     json.dump(agent_info, f, indent=4)
    #     print(f"Plan saved into {day} for agent {agent_name}.")
    #
    # return plan_list, agent_plan, agent_info

# ======== Define function extract agent actions ======== #
def extract_agent_action(output: list) -> list:
    extracted_data_list = []
    
    for agent_action_instance, observation in output:
        # Create a dictionary with the extracted attributes
        extracted_data = {
            "tool": agent_action_instance.tool,
            "tool_input": agent_action_instance.tool_input,
            "log": agent_action_instance.log,
            "observation": observation
        }
        
        extracted_data_list.append(extracted_data)
    
    return extracted_data_list

# ======== Define function to format the time ======== #
# def format_time_with_date(plan: str, date_str: str) -> str:
#     # Adjusted regex to capture time with 1 or 2 digits for hours and minutes
#     match = re.search(r"\[(\d{1,2}:\d{1,2})", plan)
#     start_time_str = match.group(1) if match else None
#
#     # If no time is captured, return None
#     if not start_time_str:
#         return None
#
#     # Extract the date components from the date string
#     date_obj = datetime.strptime(date_str, "%B %d, %Y, %H:%M")
#
#     # Merge the date components with the extracted time
#     merged_datetime = datetime(date_obj.year, date_obj.month, date_obj.day,
#                                int(start_time_str.split(':')[0]), int(start_time_str.split(':')[1]))
#     formatted_time = merged_datetime.strftime("%B %d, %Y, %H:%M")
#     return formatted_time
def format_time_with_date(plan: str, date_str: str) -> str:
    # Adjusted regex to capture time in the format 'YYYY-MM-DD - HH:MM - HH:MM'
    # This regex will capture the first time slot
    match = re.search(r"\[\d{4}-\d{2}-\d{2} - (\d{2}:\d{2}) - \d{2}:\d{2}\]", plan)
    start_time_str = match.group(1) if match else None

    # If no time is captured, return date_str as it is
    if not start_time_str:
        return date_str

    try:
        # Extract the date components from the date string
        date_obj = datetime.strptime(date_str, "%B %d, %Y, %H:%M")

        # Merge the date components with the extracted time
        merged_datetime = datetime(date_obj.year, date_obj.month, date_obj.day,
                                   int(start_time_str.split(':')[0]), int(start_time_str.split(':')[1]))
        formatted_time = merged_datetime.strftime("%B %d, %Y, %H:%M")
        return formatted_time
    except ValueError as e:
        # Handle potential date parsing errors
        print(f"Error parsing date: {e}")
        return None
