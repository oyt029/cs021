# Smart Home Simulator
This is a smart home project built upon Pygame engine and GPT agent.

# Environment Setup
This project is developed and tested on the following environment:

- Operating System: Ubuntu 22.04
- Programming Language: Python 3.9.17

# Installation
To set up your local development environment, follow these steps:

### Clone the repository:
```
git clone https://github.sydney.edu.au/tyao0172/cs34.git
```

### Install required packages:

Ensure you have Python 3.9.17 installed and then run:

```
pip install -r requirements.txt
```

### Running the Simulator
To start the simulator, execute the following command in the terminal:
```
python -m main_simulation
```

This command will launch the Smart Home Simulator. Follow the on-screen instructions to interact with the simulation.
