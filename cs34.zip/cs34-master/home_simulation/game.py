import sys
import time
import os
import os.path as path
import json

import pygame as pg
import numpy as np
from datetime import datetime, timedelta

from home_simulation.camera import Camera
from home_simulation.player import Player
from home_simulation.map import TileMap, Obstacle
from home_simulation.time_manager import GameTime
from home_simulation.path_finding_algorithm import astar_algorithm


GREEN = (0, 255, 0)
offset = 720
room_name = {"living_room": "living room", "main_bedroom": "main bedroom", "bedroom": "bedroom", "bathroom": "bathroom",  "kitchen": "kitchen", "front_door": "front door"}
room_offset = {"living_room": 110, "main_bedroom": 310, "bedroom": 510, "bathroom": 710,  "kitchen": 910, "front_door": 1110}
y_offset = {"emma": 150, "tommie": 400, "jason": 650, "amber": 900}
WINDOW_WIDTH = 40 * 34 + offset
WINDOW_HEIGHT = 40 * 34
dialog_box_size = (280, 200)
room_box_size = (240, 180)
TITLE = "Home Simulation"
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
FPS = 60
vec = pg.math.Vector2

class Game:
    def __init__(self, plan=None):
        # init game and screen
        pg.init()
        self.screen = pg.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pg.display.set_caption(TITLE)
        self.clock = pg.time.Clock()

        # get the folder path
        game_folder = path.dirname(__file__)
        self.img_folder = path.join(game_folder, "img")
        self.map_folder = path.join(game_folder, 'map')

        # map setting
        self.map = TileMap(path.join(self.map_folder, 'map.tmx'))
        self.map_img = self.map.make_map()
        self.map_rect = self.map_img.get_rect()

        # camera setting
        self.camera = Camera(self.map.width, self.map.height)
        
        # game time setting
        self.game_time = GameTime(plan[0]["time"], plan[0]["date"]) if plan else GameTime("7:00", "2023-09-01")
        # self.game_time = GameTime(plan[0]["time"]) if plan else GameTime("7:00")

        # walls setting
        self.walls = pg.sprite.Group()

        # dialog setting
        self.dialog_box = pg.image.load(path.join(self.map_folder, 'dialog_box.png')).convert_alpha()
        self.dialog_box = pg.transform.scale(self.dialog_box, dialog_box_size)

        #room information box
        self.room_box = pg.image.load(path.join(self.map_folder, 'box.png')).convert_alpha()
        self.room_box = pg.transform.rotate(self.room_box, 90)
        self.room_box = pg.transform.scale(self.room_box, room_box_size)

        # sprites setting
        self.all_sprites = pg.sprite.Group()
        self.emma, self.tommie, self.jason, self.amber = self._init_sprites()

        self.players = {"emma": self.emma, "tommie": self.tommie, "jason": self.jason, "amber": self.amber}
   
        # init grid map
        self.grid_map = self._init_grid_map()
        self.scene_pos = self.get_scene_pos()
                
        # init plan
        self.plan = plan if plan else []
        self.next_plan_index = 0

        # init environment data
        self.envs = self.init_env()

        self.sidebar_rects = {}

        self.index_list = []


    def _init_grid_map(self):
        grid_map = np.zeros((self.map.tmxdata.height, self.map.tmxdata.width), dtype=int).tolist()
        for wall in self.walls:
            g_x = int(wall.x / self.map.tmxdata.tilewidth)
            g_y = int(wall.y / self.map.tmxdata.tileheight)
            g_w = int(wall.w / self.map.tmxdata.tileheight)
            g_h = int(wall.h / self.map.tmxdata.tileheight)
            
            end_y = g_y+g_h
            end_x = g_x+g_w
            for x in range(g_x, end_x+1):
                for y in range(g_y, end_y+1):
                    grid_map[y][x] = 1

        return grid_map
        

    def _init_sprites(self):
        emma, jason, tommie, amber = None, None, None, None
        for tile_object in self.map.tmxdata.objects:
            if tile_object.name == 'man':
                jason = Player(self.all_sprites, "jason", vec(tile_object.x, tile_object.y), self.img_folder)
            elif tile_object.name == 'woman':
                emma = Player(self.all_sprites, "emma", vec(tile_object.x, tile_object.y), self.img_folder)
            elif tile_object.name == 'kid':
                tommie = Player(self.all_sprites, "tommie", vec(tile_object.x, tile_object.y), self.img_folder)
            elif tile_object.name == 'player':
                amber = Player(self.all_sprites, "amber", vec(tile_object.x, tile_object.y), self.img_folder)
            elif tile_object.name == 'walls':
                Obstacle(self.walls, tile_object.x, tile_object.y, tile_object.width, tile_object.height)
        return emma, tommie, jason, amber


    def get_scene_pos(self):
        scene_pos = {
            "bathroom": (24,14),
            "bedroom": (13,12),
            "front_door": (14, 27),
            "kitchen": (5,14),
            "living_room": (5,3),
            "main_bedroom": (26,6)
        }
        return scene_pos


    def init_env(self):
        envdata_path = path.join(path.dirname(path.dirname(__file__)), "data", "envData")
        envs = {}
        for room in os.listdir(envdata_path):
            roompath = path.join(envdata_path, room)
            with open(roompath, 'r') as file:
                roomdata = json.load(file)
                roomname = roomdata["room"]
                envs[roomname] = {
                        "temperature": roomdata["temperature"],
                        "humidity": roomdata["humidity"],
                        "air_conditioner": roomdata["air_conditioner"]["power"],
                        "ceiling_light": roomdata["ceiling_light"]["power"],
                        "humidifier": roomdata["humidifier"]["power"]
                    }

        return envs


    def display_game_time(self):
        font = pg.font.SysFont('Arial', 25)
        date, game_hour, game_minute = self.game_time.get_time()
        time_str = f"{date} {int(game_hour):02}:{int(game_minute):02}"
        time_text = font.render(time_str, True, BLACK)
        self.screen.blit(time_text, (WINDOW_WIDTH + 10 - offset, 10))


    def project2screen(self, pos):
        return (pos - self.camera.center)
        

    def draw_map(self):
        self.screen.blit(self.map_img, self.camera.apply_rect(self.map_rect))


    def is_position_occupied(self, pos, plan_player):
        for name, player in self.players.items():
            if name != plan_player and player.grid_pos == pos:
                return True
        return False


    def split_text_into_segments(self, text, max_length=30):
        words = text.split()
        segments = []
        current_segment = ""

        for word in words:
            if len(current_segment) + len(word) + 1 <= max_length:
                current_segment += word + " "
            else:
                segments.append(current_segment)
                current_segment = word + " "
        if current_segment:
            segments.append(current_segment)

        return segments


    def update_sidebar(self):
        date, g_hour, g_minute = self.game_time.get_time()
        date = datetime.strptime(date, '%Y-%m-%d')
        index_list = self.index_list
        remove_list = []
        for i, _ in enumerate(index_list):
            next_date = self.plan[_]['date']
            next_date = datetime.strptime(next_date, '%Y-%m-%d')
            next_time = self.plan[_]['time']
            next_hour = int(next_time.split(':')[0])
            next_minute = int(next_time.split(':')[1])
            duration_minute = int(self.plan[_]['duration'])
            total_minutes = next_minute + duration_minute
            
            if total_minutes >= 60:
                additional_hours = total_minutes // 60
                next_minute = total_minutes % 60
                next_hour += additional_hours
            else:
                next_minute = total_minutes % 60

            if next_hour >= 24:
                additional_days = next_hour // 24
                next_hour %= 24
                next_date += timedelta(days=additional_days)
            
            if date > next_date or (date == next_date and g_hour > next_hour) or (date == next_date and g_hour == next_hour and g_minute > next_minute):
                remove_list.append(i)

        for j in sorted(remove_list, reverse=True):
            self.index_list.pop(j)
        
            
        # Action details
        for next_plan_index in self.index_list:
            self.screen.blit(self.dialog_box, (WINDOW_WIDTH - offset + 100, y_offset[self.plan[next_plan_index]['player']]-20))
            font = pg.font.SysFont('Arial', 16)
            action_length = len(self.plan[next_plan_index]['action'])
            if(action_length <= 20):
                action_text = font.render(f"{self.plan[next_plan_index]['action']}", True, BLACK)
                self.screen.blit(action_text, (WINDOW_WIDTH - offset + 120, y_offset[self.plan[next_plan_index]['player']] + 40))

                position_text = font.render(f"Position: {self.plan[next_plan_index]['act_place']}", True, BLACK)
                self.screen.blit(position_text, (WINDOW_WIDTH - offset + 120, y_offset[self.plan[next_plan_index]['player']] + 60))

                duration_text = font.render(f"Duration: {self.plan[next_plan_index]['duration']} mins", True, BLACK)
                self.screen.blit(duration_text, (WINDOW_WIDTH - offset + 120, y_offset[self.plan[next_plan_index]['player']] + 80))
            else:
                segments = self.split_text_into_segments(text = self.plan[next_plan_index]['action'])
                for i, s in enumerate(segments):
                    action_text = font.render(f"{s}", True, BLACK)
                    self.screen.blit(action_text, (WINDOW_WIDTH - offset + 120, y_offset[self.plan[next_plan_index]['player']]+ 40 + i*20))
                
                position_text = font.render(f"Position: {self.plan[next_plan_index]['act_place']}", True, BLACK)
                self.screen.blit(position_text, (WINDOW_WIDTH - offset + 120, y_offset[self.plan[next_plan_index]['player']] + 40 + len(segments) * 20))

                duration_text = font.render(f"Duration: {self.plan[next_plan_index]['duration']} mins", True, BLACK)
                self.screen.blit(duration_text, (WINDOW_WIDTH - offset + 120, y_offset[self.plan[next_plan_index]['player']] + 60 + len(segments) * 20))

    
    def check_plan(self):
        if self.next_plan_index < len(self.plan):
            next_plan_player = self.plan[self.next_plan_index]['player']
            next_date = self.plan[self.next_plan_index]['date']
            next_date = datetime.strptime(next_date, '%Y-%m-%d')
            next_time = self.plan[self.next_plan_index]['time']
            next_hour = int(next_time.split(':')[0])
            next_minute = int(next_time.split(':')[1])
            date, game_hour, game_minute = self.game_time.get_time()
            date = datetime.strptime(date, '%Y-%m-%d')

            if date > next_date or (date == next_date and game_hour > next_hour) or (date == next_date and game_hour == next_hour and game_minute >= next_minute):
                self.index_list.append(self.next_plan_index)
                # self.update_sidebar()
                target_position = self.plan[self.next_plan_index]['position']
                is_occupied = self.is_position_occupied(target_position, next_plan_player)
                if is_occupied:
                    target_position = (target_position[0], target_position[1]+1)
                self.players[next_plan_player].player_path = astar_algorithm(self.players[next_plan_player].grid_pos, target_position, self.grid_map)
                self.players[next_plan_player].player_step = 0
                self.next_plan_index += 1
                print()


    def update_player_path(self):
        for p in self.players.values():
            if p.player_step < len(p.player_path):
                p.grid_pos = p.player_path[p.player_step]
                p.update_player_pos_by_grid_pos()
                p.player_step += 1


    def update_plan(self, plan: list):
        self.plan = plan


    def draw_players(self):
        for sprite in self.all_sprites:
            self.screen.blit(sprite.image,  self.camera.apply(sprite))
        pg.time.wait(100)


    def draw_sidebar(self):
        self.sidebar_rects = {}
        sidebar_rect = pg.Rect(WINDOW_WIDTH - offset, 0, offset, WINDOW_HEIGHT)
        pg.draw.rect(self.screen, WHITE, sidebar_rect)
        
        font = pg.font.SysFont('Arial', 25)
        label = font.render("Agents:", True, BLACK)
        self.screen.blit(label, (WINDOW_WIDTH - offset + 10, 40))
        
        font = pg.font.SysFont('Arial', 20)
        for name, player in self.players.items():
            self.screen.blit(player.image, (WINDOW_WIDTH - offset + 20, y_offset[name]))
            self.sidebar_rects[name] = (WINDOW_WIDTH - offset + 20, y_offset[name])
            name_text = font.render(name.capitalize(), True, BLACK)
            self.screen.blit(name_text, (WINDOW_WIDTH - offset + 20, y_offset[name] + 100))


    def draw_envdata(self):
        font = pg.font.SysFont('Arial', 25)
        rooms = "Rooms: "
        rooms_text = font.render(rooms.capitalize(), True, BLACK)
        self.screen.blit(rooms_text, (WINDOW_WIDTH - offset + 430, 50))
        for idx_, room in enumerate(self.envs.keys()):
            font = pg.font.SysFont('Arial', 22)
            room_ = room_name[room] + ": "
            room_text = font.render(room_.capitalize(), True, BLACK)
            self.screen.blit(self.room_box, (WINDOW_WIDTH - offset + 430, room_offset[room] - 20))
            self.screen.blit(room_text, (WINDOW_WIDTH - offset + 450, room_offset[room]))
            
            font = pg.font.SysFont('Arial', 18)
            for idx, (i, j) in enumerate(self.envs[room].items()):
                text_i = font.render(i + ": " + j, True, BLACK)
                self.screen.blit(text_i, (WINDOW_WIDTH - offset + 460, room_offset[room] + idx * 20 + 30))


    def update_envData(self):
        envdata_path = path.join(path.dirname(path.dirname(__file__)), "data", "envData")
        for room in os.listdir(envdata_path):
            roompath = path.join(envdata_path, room)
            with open(roompath, 'r') as file:
                roomdata = json.load(file)
                roomname = roomdata["room"]
                self.envs[roomname]["temperature"] = roomdata["temperature"]
                self.envs[roomname]["humidity"] = roomdata["humidity"]
                self.envs[roomname]["air_conditioner"] = roomdata["air_conditioner"]["power"]
                self.envs[roomname]["ceiling_light"] = roomdata["ceiling_light"]["power"]
                self.envs[roomname]["humidifier"] = roomdata["humidifier"]["power"]


    def update(self):
        self.all_sprites.update()
        self.camera.update()
        

    def run(self):
        running = True
        last_time = time.time()

        while running:

            mouse_pos = pg.mouse.get_pos()

            for event in pg.event.get():
                if event.type == pg.QUIT:
                    running = False

                self.camera.handle_event(event)

            self.screen.fill(BLACK)
            self.camera.update()
            self.update()
            self.draw_map()
            self.draw_players()
            self.draw_sidebar()
            self.draw_envdata()
            self.display_game_time()

            current_time = time.time()
            dt = current_time - last_time 
            last_time = current_time

            self.game_time.update(dt)

            self.check_plan()
            self.update_sidebar()
            
            self.update_player_path()
            self.update_envData()

            pg.display.flip()
            self.clock.tick(FPS)

        pg.quit()
        sys.exit()


def generate_init_plan():
    scene_pos = {
            "bathroom": (24,14),
            "bedroom": (13,12),
            "front_door": (14, 27),
            "kitchen": (5,14),
            "living_room": (5,3),
            "main_bedroom": (26,6)
        }
    init_plan = []
    parent_dir = path.dirname(path.dirname(__file__))
    agentdata_path = path.join(parent_dir, "data", "agentData")

    players = ["emma", "tommie", "jason", "amber"]
    for player in players:
        json_path = path.join(agentdata_path, player+".json")
        with open(json_path, 'r') as file:
            data = json.load(file)
            for day in data:
                act_plan = day.get('act_plan', {})

                for a in act_plan:
                    plan = {}
                    plan["date"] = a["start_date"]
                    plan["time"] = a["start_time"]
                    plan["player"] = player
                    plan["position"] = scene_pos.get(a["act_place"], "living_room")
                    plan["action"] = a["action"]
                    plan["act_place"] = a["act_place"]
                    plan["duration"] = a["duration"]
                    init_plan.append(plan)
    return init_plan




def main():

    init_plan = generate_init_plan()
    init_plan.sort(key=lambda x: (x["date"], x["time"]))
    # init_plan.sort(key=lambda x: (x["time"] == "00:00", x["time"]))
    print(init_plan)
    # init_plan = [
    #     {"time": "7:40", "player": "emma", "position": (5, 3)}, 
    #     {"time": "7:45", "player": "tommie", "position": (5, 14)},
    #     {"time": "7:45", "player": "jason", "position": (14, 27)},
    #     {"time": "7:50", "player": "emma", "position": (1,1)},
    #     {"time": "8:10", "player": "tommie", "position": (15,4)},
    #     {"time": "8:20", "player": "jason", "position": (7,13)},
    # ]

    game = Game(init_plan)
    game.run()
    
if __name__ == "__main__":
    main()