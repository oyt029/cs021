import os.path as path

import pygame as pg
vec = pg.math.Vector2

player_width = 48
player_height = 48 * 2
player_scale = 1
player_imgs_name = {
    'tommie': 'man.png',
    'emma': 'woman.png',
    'jason': 'kid.png',
    'amber': 'amber.png'
}

TILESIZE = 48

class Player(pg.sprite.Sprite):
    def __init__(self, all_sprites, name, pos, image_folder):
        self.groups = all_sprites
        pg.sprite.Sprite.__init__(self, self.groups)

        self.player_name = name
        self.player_pos = pos
        self.grid_pos = (int(pos[0]/TILESIZE), int(pos[1]/TILESIZE))
        self.player_path = []
        self.player_step = 0

        self.direction = 'down'
        self.player_images_folder = image_folder
        self.player_images = self._init_player_image()
        self.image = self.player_images[self.direction]
        self.rect = self.image.get_rect()
        self.rot = 0
    
    def update_player_pos_by_grid_pos(self):
        self.player_pos = vec(self.grid_pos[0]*TILESIZE, self.grid_pos[1]*TILESIZE)

    def _get_character_image(self, player_image, direction):
        image = pg.Surface((player_width, player_height), pg.SRCALPHA).convert_alpha()
        image.blit(player_image, (0, 0), (direction * player_width, 0, player_width, player_height))

        return pg.transform.scale(image, (int(player_width * player_scale), int(player_height * player_scale))).convert_alpha()

    def _init_player_image(self):
        image_name = player_imgs_name[self.player_name]
        player_image = pg.image.load(path.join(self.player_images_folder, image_name)).convert_alpha()
        player_images= {
            'left': self._get_character_image(player_image, 2),
            'right': self._get_character_image(player_image, 0),
            'up': self._get_character_image(player_image, 1),
            'down': self._get_character_image(player_image, 3)
        }
        return player_images
    
    def update(self):
        self.rect.x = self.player_pos.x
        self.rect.y = self.player_pos.y