<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="decoretes" tilewidth="48" tileheight="48" tilecount="13744" columns="16">
 <image source="Interiors_48x48.png" width="768" height="41232"/>
</tileset>
