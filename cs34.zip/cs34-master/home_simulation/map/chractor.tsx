<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="chractor" tilewidth="48" tileheight="48" tilecount="864" columns="48">
 <image source="Amelia_48x48.png" width="2304" height="864"/>
</tileset>
