<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="bathroom" tilewidth="48" tileheight="48" tilecount="896" columns="16">
 <image source="3_Bathroom_48x48.png" width="768" height="2688"/>
</tileset>
