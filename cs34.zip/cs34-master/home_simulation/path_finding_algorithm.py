import math
import heapq

GRIDWIDTH = 40
GRIDHEIGHT = 35

class Node:
    def __init__(self, x, y, parent=None):
        self.x = x
        self.y = y
        self.parent = parent

        self.g = 0  # Cost from the start to this node
        self.h = 0  # Heuristic cost from this node to the end node
        self.f = 0  # Total cost (g + h)

    def __eq__(self, other):
        return self.x == other.x and self.y == other.y

    def __lt__(self, other):
        return self.f < other.f

    def __repr__(self):
        return f"({self.x},{self.y})"

def astar_algorithm(start, end, grid):
    open_list = []
    closed_set = set()

    start_node = Node(start[0], start[1])
    end_node = Node(end[0], end[1])

    heapq.heappush(open_list, (start_node.f, start_node))

    while open_list:
        _, current_node = heapq.heappop(open_list)

        if (current_node.x, current_node.y) in closed_set:
            continue

        closed_set.add((current_node.x, current_node.y))

        if current_node.x == end_node.x and current_node.y == end_node.y:
            path = []
            current = current_node
            while current:
                path.append((current.x, current.y))
                current = current.parent
            return path[::-1]

        neighbors = []
        for i, j in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
            x, y = current_node.x + i, current_node.y + j
            if 0 <= x < GRIDWIDTH and 0 <= y < GRIDHEIGHT and grid[y][x] == 0:
                neighbors.append(Node(x, y))

        for neighbor in neighbors:
            if (neighbor.x, neighbor.y) in closed_set:
                continue

            neighbor.g = current_node.g + 1
            neighbor.h = math.sqrt((neighbor.x - end_node.x) ** 2 + (neighbor.y - end_node.y) ** 2)
            neighbor.f = neighbor.g + neighbor.h
            neighbor.parent = current_node

            for index, (_, existing_node) in enumerate(open_list):
                if existing_node.x == neighbor.x and existing_node.y == neighbor.y and existing_node.g > neighbor.g:
                    open_list[index] = (neighbor.f, neighbor)
                    break
            else:
                heapq.heappush(open_list, (neighbor.f, neighbor))

    return []