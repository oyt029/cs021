import pygame as pg

WIDTH = 40 * 34
HEIGHT = 40 * 34

class Camera:
    def __init__(self, width, height):
        self.camera = pg.Rect(0, 0, width, height)
        self.width = width
        self.height = height
        self.dragging = False
        self.last_mouse_pos = pg.Vector2(0, 0)

    def handle_event(self, event):
        if event.type == pg.MOUSEBUTTONDOWN:
            if event.button == 1:  
                self.dragging = True
                self.last_mouse_pos = pg.Vector2(event.pos)
        elif event.type == pg.MOUSEBUTTONUP:
            if event.button == 1:
                self.dragging = False

    

    def apply(self, entity, zoom_level=1):
            return entity.rect.move(self.camera.topleft).inflate(
                entity.rect.width * zoom_level - entity.rect.width,
                entity.rect.height * zoom_level - entity.rect.height
            )

    def apply_rect(self, rect, zoom_level=1):
        return rect.move(self.camera.topleft).inflate(
            rect.width * zoom_level - rect.width,
            rect.height * zoom_level - rect.height
        )

    def update(self):
        if self.dragging:
            current_mouse_pos = pg.Vector2(pg.mouse.get_pos())
            movement = self.last_mouse_pos - current_mouse_pos
            self.camera.move_ip(movement)
            self.last_mouse_pos = current_mouse_pos

            self.camera.x = min(0, self.camera.x)
            self.camera.y = min(0, self.camera.y)
            self.camera.x = max(-(self.width - WIDTH), self.camera.x)
            self.camera.y = max(-(self.height - HEIGHT), self.camera.y)
            # self.camera = pygame.Rect(x, y, self.width, self.height)

            # self.camera.x = max(min(self.camera.x, 0), -(self.width - WINDOW_WIDTH))
            # self.camera.y = max(min(self.camera.y, 0), -(self.height - WINDOW_HEIGHT))