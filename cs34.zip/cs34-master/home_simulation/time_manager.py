from datetime import datetime, timedelta

class GameTime:
    def __init__(self, game_seconds_passed="7:30", start_date="2023-09-01"):
        # 10mins -> 600s, 600s -> 24h -> 86400s
        self.ratio = 86400 / 600 
        self.game_seconds_passed = self.convert_str_to_time(game_seconds_passed)
        self.start_date = datetime.strptime(start_date, "%Y-%m-%d")

    def update(self, dt):
        # dt is real time, using ratio to get game time
        self.game_seconds_passed += dt * self.ratio
        # Check if days need to be added
        if self.game_seconds_passed >= 86400:
            days_passed = int(self.game_seconds_passed // 86400)
            self.start_date += timedelta(days=days_passed)
            self.game_seconds_passed = self.game_seconds_passed % 86400

    def get_time(self):
        # trans seconds to h and m
        hours = self.game_seconds_passed // 3600
        minutes = (self.game_seconds_passed % 3600) // 60
        return (self.start_date.strftime('%Y-%m-%d'), int(hours), int(minutes))
        # return hours, minutes

    def convert_str_to_time(self, time_str):
        # convert "HH:MM" to minutes since start of day
        parts = time_str.split(":")
        return int(parts[0]) * 60 * 60 + int(parts[1]) * 60