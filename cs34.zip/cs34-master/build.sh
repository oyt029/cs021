echo "Build new image"
docker build --network=host -t simhome:dev_sim -f Dockerfile .

echo "show unused none images: "
docker images -f "dangling=true"
echo "remove unused none images"
docker rmi $(docker images -f "dangling=true" -q)

echo "server running"
# docker run --rm -it -p 50000-50008:50000-50008 --name dev_sim simhome:dev_sim
docker run -it --name dev_sim simhome:dev_sim bash